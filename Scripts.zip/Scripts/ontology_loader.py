from owlready2 import *
import json
from geo_unit import computeBearing


def load_counties():
    counties = dict()
    with open("wales_counties.json", "r") as read_file:
        data = json.load(read_file)

    for item in data:
        counties[item["name"]] = item

    return counties


# for regions


def load_regions():

    regions = dict()
    with open("wales_regions.json", "r") as read_file:
        data = json.load(read_file)

    for item in data:
        regions[item["name"]] = item

    return regions
#####


def load_ontology():
    #get_ontology() function; takes the IRI of the ontology.
    onto = get_ontology('ontology/Ontology_V30.owl').load()
    base_iri = onto.base_iri
    print(base_iri)
    return onto


def get_entity(onto, name):
    return onto[name]


def update_ontology(onto):
    # get individual by name

    Administrative_Unit = get_entity(onto, "Administrative_Unit")
    proximity_directional = get_entity(onto, "proximity_directional")
    County_Administrative_Unit = get_entity(onto, "County_Administrative_Unit")
    Region_Administrative_Unit = get_entity(onto, "Region_Administrative_Unit")



    with onto:
        class touch_N(proximity_directional):
            pass

        class touch_S(proximity_directional):
            pass

        class touch_W(proximity_directional):
            pass

        class touch_E(proximity_directional):
            pass

        class touch_NE(proximity_directional):
            pass

        class touch_SE(proximity_directional):
            pass

        class touch_NW(proximity_directional):
            pass

        class touch_SW(proximity_directional):
            pass


    # claculate direction for counties

    counties = load_counties()
    for name, county in counties.items():
        cur_coordinator = {k: v for k, v in county.items() if k in ["lat", "long"]}

        for neighbour_name in county["neighbours"]:
            neighbour = counties[neighbour_name]
            ngb_coordinator = {k: v for k, v in neighbour.items() if k in ["lat", "long"]}

            bearing = computeBearing(ngb_coordinator, cur_coordinator)

            # add and update new relation
            with onto:
                #matching the instataces
                cur_county = get_entity(onto, name)
                ngb_county = get_entity(onto, neighbour_name)
                if bearing == "N":
                    cur_county.touch_N.append(ngb_county)
                if bearing == "S":
                    cur_county.touch_S.append(ngb_county)
                if bearing == "E":
                    cur_county.touch_E.append(ngb_county)
                if bearing == "W":
                    cur_county.touch_W.append(ngb_county)
                if bearing == "NE":
                    cur_county.touch_NE.append(ngb_county)
                if bearing == "SE":
                    cur_county.touch_SE.append(ngb_county)
                if bearing == "NW":
                    cur_county.touch_NW.append(ngb_county)
                if bearing == "SW":
                    cur_county.touch_SW.append(ngb_county)








# regions


    # update bearing direction for regions
    regions = load_regions()
    for name, region in regions.items():
        cur_coordinator = {k: v for k, v in region.items() if k in ["lat", "long"]}

        for neighbour_name in region["neighbours"]:
            neighbour = regions[neighbour_name]
            ngb_coordinator = {k: v for k, v in neighbour.items() if k in ["lat", "long"]}

            bearing = computeBearing(ngb_coordinator, cur_coordinator)

            # add new relation
            with onto:
                #matching the instataces
                cur_region = get_entity(onto, name)
                ngb_region = get_entity(onto, neighbour_name)
                if bearing == "N":
                    cur_region.touch_N.append(ngb_region)
                if bearing == "S":
                    cur_region.touch_S.append(ngb_region)
                if bearing == "E":
                    cur_region.touch_E.append(ngb_region)
                if bearing == "W":
                    cur_region.touch_W.append(ngb_region)


    # write to file
    onto.save('ontology_v9.owl')


if __name__ == "__main__":
    onto = load_ontology()
    update_ontology(onto)



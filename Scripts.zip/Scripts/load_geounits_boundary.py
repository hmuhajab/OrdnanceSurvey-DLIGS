from rdflib.term import URIRef
from rdflib import Graph
import re
import pathlib
import pickle

gml_attribute = "<http://data.ordnancesurvey.co.uk/ontology/geometry/asGML>"
gml_extend = "<http://data.ordnancesurvey.co.uk/ontology/geometry/extent>"

def get_triple(line):
    line = line.strip()[:-1].strip()
    first_space_idx = line.find(" ")
    sencond_space_idx = line.find(" ", first_space_idx+1)
    # print(first_space_idx, sencond_space_idx)
    if first_space_idx > -1 and sencond_space_idx > -1:
        sub = line[:first_space_idx].strip()
        pred = line[first_space_idx+1:sencond_space_idx].strip()
        obj = line[sencond_space_idx+1:].strip()

        return sub, pred, obj
    return None
    

def extract_boundary(gml_polygon_text_value):
    boundary = []
    line = gml_polygon_text_value.replace("^^<http://www.w3.org/1999/02/22-rdf-syntax-ns#XMLLiteral>", "")
    # remove " and " on both sides
    line = line[1:-1]
    # split by group of polygons
    coordinates_pattern = r"<gml:coordinates>[0-9,\. ]*<\/gml:coordinates>"
    parts = re.findall(coordinates_pattern, line)
    
    for part in parts:
        polygon = []        
        # split by space
        coordinates = part.strip().split(" ")
        coordinates[0] = coordinates[0].replace("<gml:coordinates>","")
        coordinates[-1] = coordinates[-1].replace("</gml:coordinates>","")
        for coordinate in coordinates:
            xy = coordinate.split(",")
            x = float(xy[0])
            y = float(xy[1])
            polygon.append((x, y))
        boundary.append(polygon)
    return boundary


def read_nt_file_with_fix_uri_space(filepath: str):
    lines = []
    with open(filepath, encoding="utf-8") as fin:
        for row in fin.readlines():
            # split by >.<
            items = row.strip().split(">.<")
            # print(items)
            subrows = []
            if len(items) > 1:
                subrows.append(items[0] + ">.")
                for item in items[1:]:
                    subrows.append("<"+item)
            else:
                subrows.append(items[0])
            
            for subrow in subrows:               
                lines.append(subrow)
    return lines

def load_geo_data(geo_data_nt_file):
    geo_data = {}
    
    lines = read_nt_file_with_fix_uri_space(geo_data_nt_file)

    for line in lines:
        # print(line)
        triple = get_triple(line)
        if triple:
            sub = triple[0]            
            pred = triple[1]           
            obj = triple[2]
            if pred != gml_attribute:
                continue         
            geo_data[sub] = extract_boundary(obj)
    return geo_data    

def load_all_geo_data():
    all_geo_data = {}
    for ntfile in pathlib.Path("ntriples/geodata/").glob('*.nt'):
        print("processing ...... ", ntfile)
        all_geo_data.update(load_geo_data(ntfile))
    return all_geo_data


def load_geo_info(geo_info_nt_file):
    geo_info = {}
    
    lines = read_nt_file_with_fix_uri_space(geo_info_nt_file)

    for line in lines:
        # print(line)
        triple = get_triple(line)
        if triple:
            sub = triple[0]            
            pred = triple[1]           
            obj = triple[2]
            if pred != gml_extend:
                continue          
            geo_info[sub] = obj
    return geo_info   

def load_all_geo_info():
    all_geo_info = {}
    for ntfile in pathlib.Path("ntriples/geoinfo/").glob('*.nt'):
        print("processing ...... ", ntfile)
        all_geo_info.update(load_geo_info(ntfile))
    return all_geo_info 


def save_all_geounit_geometry():
    geounit_geomerties = {}
    
    all_geo_data = load_all_geo_data()
    all_geo_info = load_all_geo_info()

    for geouri, geoextend in all_geo_info.items():
        geounit_geomerties[geouri] = all_geo_data[geoextend]

    with open("all_geounit_geometry.pickle", "wb") as outfile:
        pickle.dump(geounit_geomerties, outfile, pickle.HIGHEST_PROTOCOL)

def extract_wards_geometry():
    with open("all_geounit_geometry.pickle", "rb") as infile:
        geounit_geomerties = pickle.load(infile)

    with open("local_wales_wards.pickle", "rb") as infile:
        wards = pickle.load(infile)

    wards_geometry = {}
    for warduri in wards.keys():
        print(warduri)
        wards_geometry[warduri] = geounit_geomerties["<"+warduri+">"]

    with open("local_wales_wards_geometry.pickle", "wb") as outfile:
        pickle.dump(wards_geometry, outfile, pickle.HIGHEST_PROTOCOL)



def extract_wards_geometry_England():
    with open("all_geounit_geometry.pickle", "rb") as infile:
        geounit_geomerties = pickle.load(infile)

    with open("local_england_wards.pickle", "rb") as infile:
        wards = pickle.load(infile)

    wards_geometry = {}
    for warduri in wards.keys():
        print(warduri)
        wards_geometry[warduri] = geounit_geomerties["<"+warduri+">"]

    with open("local_england_wards_geometry.pickle", "wb") as outfile:
        pickle.dump(wards_geometry, outfile, pickle.HIGHEST_PROTOCOL)

def test_saved_geounit_geometry():
    with open("all_geounit_geometry.pickle", "rb") as infile:
        geounit_geomerties = pickle.load(infile)

    for warduri, warddata in geounit_geomerties.items():
        print(warduri)
        print(warddata)
        break

    # while True:
    #     warduri = input("Enter ward uri: ")
    #     if warduri == "quit":
    #         break
    #
    #     print(warduri)
    #     ward_geometry = geounit_geomerties[warduri]
    #     print(ward_geometry)

if __name__ == "__main__":

    # testing for RegEx
    # coordinates_pattern = r"<gml:coordinates>[0-9,\. ]*<\/gml:coordinates>"
    # text = "<gml:MultiPolygon><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>193162.6986999999,47114.103</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember><gml:polygonMember><gml:Polygon><gml:outerBoundaryIs><gml:LinearRing><gml:coordinates>192857.312,36938.50699999999 192857.312,36938.50699999999</gml:coordinates></gml:LinearRing></gml:outerBoundaryIs></gml:Polygon></gml:polygonMember></gml:MultiPolygon>"

    # results = re.findall(coordinates_pattern, text)
    
    # for res in results:
        # print(res)

    #step 1: save all geo unit information/ data  --> output : all_geounit_geometry.pickle
       save_all_geounit_geometry()

    # step 2: save only wards geo data  --> output local_wales_wards_geometry.pickle
       extract_wards_geometry_England()

    # testing saved dataset
      #test_saved_geounit_geometry()

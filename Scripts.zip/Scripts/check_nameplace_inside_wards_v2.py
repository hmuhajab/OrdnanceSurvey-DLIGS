from pygeodesy.sphericalNvector import LatLon
from pyproj import Transformer
import pickle
import pyproj
from shapely.geometry import Point, Polygon
import matplotlib.pyplot as plt ##########




#
# polygon_data_x = [] ##########
# polygon_data_y = [] ##########
#
#
# point_x = [] ##########
# point_y = [] ##########

#https://gis.stackexchange.com/questions/78838/converting-projected-coordinates-to-lat-lon-using-python
def convert_XY_to_latlong(x1, y1):
    proj = pyproj.Transformer.from_crs(27700, 4326, always_xy=True)
    lat, lon = proj.transform(x1, y1)
    return lon, lat



def get_point(lat, lon):
    return LatLon(lat, lon)




class Polygon:
    def __init__(self):
        self.polygon = []
    
    def add_point(self, lat, lon):
        # polygon_data_x.append(lat)  ##########
        # polygon_data_y.append(lon)  ##########
        self.polygon.append(LatLon(lat, lon))

#https://stackoverflow.com/questions/43892459/check-if-geo-point-is-inside-or-outside-of-polygon
    def is_containing_point(self, lat, lon):
        p = get_point(lat, lon)
        # point_x.append(lat)  ##########
        # point_y.append(lon)  ##########
        return p.isenclosedBy(self.polygon)

       # return p.within(self.polygon)


def check_point_inside_polygons(lat, lon, polygons: list):
    for polygon in polygons:
        if polygon.is_containing_point(lat, lon):
            return True
        else:
            return False




class GeoChecker:
    def __init__(self, saved_geometry_file):
        # load all wards geo data
        with open(saved_geometry_file, "rb") as infile:
            self.unit_geomerties = pickle.load(infile)

    # convert geo data of a ward into list of polygons
    def get_unit_geometry(self, warduri):
        unit_geometry_coordinates = self.unit_geomerties.get(warduri)
        unit_polygons = []
        if unit_geometry_coordinates:
            for subarea in unit_geometry_coordinates:
                polygon = Polygon()
                for boundary_point in subarea:
                    x = boundary_point[0]
                    y = boundary_point[1]
                    lat, lon = convert_XY_to_latlong(x, y)
                    polygon.add_point(lat, lon)
                # add sub-area polygon to ward polygon
                unit_polygons.append(polygon)
        return unit_polygons

    # # check if a point is inside a ward's polygons
    # def check_point_in_area(self, unituri, lat, lon):
    #     unit_polygons = self.get_unit_geometry(warduri)
    #     # p = get_point(lat, lon)
    #     return check_point_inside_polygons(lat, lon, unit_polygons)

    # checking for multiple points
    def check_multi_points_in_ward(self, warduri, points: list):
        results = []
        ward_polygons = self.get_unit_geometry(warduri)

        for point in points:
            lat = point[0]
            lon = point[1]
            checking_result = check_point_inside_polygons(lat, lon, ward_polygons)
            results.append(checking_result)
        return results


if __name__ == "__main__":
    #saved_file = "local_wales_district_geometry.pickle"
    saved_file = "local_wales_wards_geometry.pickle"

    # load GeoChecker
    geochecker = GeoChecker(saved_file)

    # load pickle file of wards   

    # district
    Swansea = "http://data.ordnancesurvey.co.uk/id/7000000000025492"

    # ward  (polygon)
    Fairwood = "http://data.ordnancesurvey.co.uk/id/7000000000025850"
    Castle = "http://data.ordnancesurvey.co.uk/id/7000000000181968"
    Cathays = "http://data.ordnancesurvey.co.uk/id/7000000000019014"
    Cyncoed = "http://data.ordnancesurvey.co.uk/id/7000000000018997"

    # name place (point)
    Glyncollen_Primary_School = "http://data.ordnancesurvey.co.uk/id/4000000073307140"
    Glyncollen_Primary_School_lat = 51.682372
    Glyncollen_Primary_School_lon = -3.918563



    # name place  (point)
    Ger_Y_Ffrwd = "http://data.ordnancesurvey.co.uk/id/4000000021060953"
    Ger_Y_Ffrwd_lat = 51.650385
    Ger_Y_Ffrwd_lon = -3.888156



    # name place
    Upper_Killay = "http://data.ordnancesurvey.co.uk/id/4000000074548728"
    Upper_Killay_lat = 51.613541
    Upper_Killay_lon = -4.038259



    # name place
    Cathays_Park = "http://data.ordnancesurvey.co.uk/id/4000000074557896"
    Cathays_Park_lat = 51.486344
    Cathays_Park_lon = -3.176817


    Roath_Park = "http://data.ordnancesurvey.co.uk/id/4000000074558279"
    Roath_Park_lat = 51.512145
    Roath_Park_lon = -3.176488



    name_places = {}
    
    name_places[Glyncollen_Primary_School] = (Glyncollen_Primary_School_lat, Glyncollen_Primary_School_lon)
    name_places[Ger_Y_Ffrwd] = (Ger_Y_Ffrwd_lat, Ger_Y_Ffrwd_lon)
    name_places[Upper_Killay] = (Upper_Killay_lat, Upper_Killay_lon)
    name_places[Cathays_Park] = (Cathays_Park_lat, Cathays_Park_lon)
    name_places[Roath_Park] = (Roath_Park_lat, Roath_Park_lon)
    name_place_uris = list(name_places.keys())
    print(name_place_uris)

    name_place_points = list(name_places.values())

   # results = geochecker.check_multi_points_in_area(Cyncoed, name_place_points)
    results = geochecker.check_multi_points_in_ward(Cathays, name_place_points)

    for i in range(len(name_place_uris)):
        print(f"Check {name_place_uris[i]} belong to {Cathays} : {results[i]}")
        # print(f"Check {name_place_uris[i]} belong to {Cyncoed} : {results[i]}")

    # print(point_x, "~", point_y)  ##########
    # print(polygon_data_x, "----", polygon_data_y)
    # plt.plot(point_x, point_y, 'ro')  ##########
    # plt.plot(polygon_data_x, polygon_data_y, 'ro')  ##########

    # plt.show()  ##########



from SPARQLWrapper import SPARQLWrapper, JSON
from geo_utils import computeBearing, GeoUnit, load_pickle_geo_units
import pprint
import json
import pickle

   

# SELECT ?district ?name ?lat ?long ?touch 
# WHERE {
#    ?x <http://data.ordnancesurvey.co.uk/ontology/admingeo/inCounty> ?district ;
#       <http://data.ordnancesurvey.co.uk/ontology/admingeo/inCountry> <http://data.ordnancesurvey.co.uk/id/country/wales> .
#    ?district <http://www.w3.org/2000/01/rdf-schema#label> ?name ;
#              <http://www.w3.org/2003/01/geo/wgs84_pos#lat> ?lat ;
#              <http://www.w3.org/2003/01/geo/wgs84_pos#long> ?long ;
#              <http://data.ordnancesurvey.co.uk/ontology/spatialrelations/touches> ?touch .
# }

def query_districts_in_wales():    
    all_districts = dict()

    # select_clause = "SELECT ?district ?name ?lat ?long ?touch "
    select_clause = "SELECT ?district "
    open_where_clause = "WHERE { "
    condition_1 = "   ?x <http://data.ordnancesurvey.co.uk/ontology/admingeo/inCounty> ?district ;"
    condition_2 = "      <http://data.ordnancesurvey.co.uk/ontology/admingeo/inCountry> <http://data.ordnancesurvey.co.uk/id/country/wales> ."   
    # condition_3 = "   ?district <http://www.w3.org/2000/01/rdf-schema#label> ?name ;"
    # condition_4 = "             <http://www.w3.org/2003/01/geo/wgs84_pos#lat> ?lat ;"
    # condition_5 = "             <http://www.w3.org/2003/01/geo/wgs84_pos#long> ?long ;"
    # condition_6 = "             <http://data.ordnancesurvey.co.uk/ontology/spatialrelations/touches> ?touch ."

    close_where_clause = "} "

    # query = "\n".join([select_clause, open_where_clause, condition_1, condition_2, condition_3, condition_4, condition_5, condition_6,close_where_clause])    
    query = "\n".join([select_clause, open_where_clause, condition_1, condition_2, close_where_clause])  
    print(query)

    sparql = SPARQLWrapper("https://data.ordnancesurvey.co.uk/datasets/os-linked-data/apis/sparql")
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    results = sparql.query().convert()    
    
    for result in results["results"]["bindings"]:
        uri = result["district"]["value"]
        adistrict = all_districts.get(uri, None)
        if not adistrict:
            adistrict = GeoUnit(uri)            
            # adistrict.name = result["name"]["value"]
            # adistrict.latitude = float(result["lat"]["value"])
            # adistrict.longtitude = float(result["long"]["value"])
            # adistrict.neighbours.append(result["touch"]["value"])
            all_districts[uri] = adistrict   
    
    with open("wales_district.pickle", "wb") as outfile:
        pickle.dump(all_districts, outfile, pickle.HIGHEST_PROTOCOL)


# SELECT ?name ?lat ?long ?touch 
# WHERE {   
#    <http://data.ordnancesurvey.co.uk/id/7000000000025491> <http://www.w3.org/2000/01/rdf-schema#label> ?name ;
#              <http://www.w3.org/2003/01/geo/wgs84_pos#lat> ?lat ;
#              <http://www.w3.org/2003/01/geo/wgs84_pos#long> ?long ;
#              <http://data.ordnancesurvey.co.uk/ontology/spatialrelations/touches> ?touch .
# }
def update_districts_in_wales():
    with open("wales_district.pickle", "rb") as infile:
        all_districts = pickle.load(infile)

    for uri, geounit in all_districts.items():
        select_clause = "SELECT ?name ?lat ?long ?touch"
        open_where_clause = "WHERE { "
        condition_3 = f"   <{uri}> <http://www.w3.org/2000/01/rdf-schema#label> ?name ;"
        condition_4 = "             <http://www.w3.org/2003/01/geo/wgs84_pos#lat> ?lat ;"
        condition_5 = "             <http://www.w3.org/2003/01/geo/wgs84_pos#long> ?long ;"
        condition_6 = "             <http://data.ordnancesurvey.co.uk/ontology/spatialrelations/touches> ?touch ."
        close_where_clause = "} "

        query = "\n".join([select_clause, open_where_clause, condition_3, condition_4, condition_5, condition_6, close_where_clause])  
        print(query)

        sparql = SPARQLWrapper("https://data.ordnancesurvey.co.uk/datasets/os-linked-data/apis/sparql")
        sparql.setQuery(query)
        sparql.setReturnFormat(JSON)
        results = sparql.query().convert()

        for result in results["results"]["bindings"]:
            geounit.name = result["name"]["value"]
            geounit.latitude = float(result["lat"]["value"])
            geounit.longtitude = float(result["long"]["value"])
            geounit.neighbours.append(result["touch"]["value"])

    with open("wales_district.pickle", "wb") as outfile:
        pickle.dump(all_districts, outfile, pickle.HIGHEST_PROTOCOL)


if __name__ == "__main__":
    # query_districts_in_wales()
    # update_districts_in_wales()
    load_pickle_geo_units("wales_district.pickle")
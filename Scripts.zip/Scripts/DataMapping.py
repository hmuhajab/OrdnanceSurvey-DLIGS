from owlready2 import *
import dill as pickle
from rdflib import URIRef


from geo_unit import GeoUnit
import pickle
import json


#def get_entity(onto, name):
  #  return onto[name]
def get_entity(onto, name):
    try:
        return onto[name]
    except KeyError:
        print(f"Entity with name '{name}' not found in the ontology.")
        return None

#def get_entity(onto, name):
    #try:
      #  return onto[name]
   # except KeyError:
 #       print(f"Entity {name} not found in the ontology.")
       # return None

def load_ontology():
    # to populate all the data
    #onto = get_ontology('ontology/ontology_England_walesclases.owl').load()
    # to populate (Lat and Long) the data
    #onto = get_ontology('ontology/ontology_All_Knowledge copy.owl').load()
    #onto = get_ontology('ontology/ontology_UK_Wales_with_Coordinates.owl').load()

    onto = get_ontology('ontology/Abstract_Updated.rdf').load()
    base_iri = onto.base_iri
    print(base_iri)

    proximity_directional = get_entity(onto, "proximity_directional")

    with onto:
        class nearest_N(proximity_directional):
            pass

        class nearest_S(proximity_directional):

            pass

        class nearest_W(proximity_directional):
            pass

        class nearest_E(proximity_directional):
            pass





    return onto


def get_mapping_uri2name_districts():
    with open("wales_uri2name_district.pickle", "rb") as infile:
        mapping_uri2name_districts = pickle.load(infile)
    return mapping_uri2name_districts





def get_mapping_uri2name_wards():
    with open("wales_uri2name_ward.pickle", "rb") as infile:
        mapping_uri2name_wards = pickle.load(infile)
    return mapping_uri2name_wards



def get_mapping_uri2name_parishes():
    with open("wales_uri2name_parish.pickle", "rb") as infile:
        mapping_uri2name_parishes = pickle.load(infile)
    return mapping_uri2name_parishes

#
# def get_mapping_uri2name_place():
#     with open("wales_uri2name_place1.pickle", "rb") as infile:
#         mapping_uri2name_place = pickle.load(infile)
#     return mapping_uri2name_place


# def get_mapping_uri2name_place2():
#     with open("wales_uri2name_place2.pickle", "rb") as infile:
#         mapping_uri2name_place2 = pickle.load(infile)
#     return mapping_uri2name_place2

def get_mapping_uri2name_place():
    with open("wales_uri2name_place_output_with_ward_updated.pickle", "rb") as infile:
        mapping_uri2name_place = pickle.load(infile)
    return mapping_uri2name_place


def get_mapping_uri2name_postal_area():
    with open("wales_uri2name_postal_area.pickle", "rb") as infile:
        mapping_uri2name_postal_area = pickle.load(infile)
    return mapping_uri2name_postal_area






def get_mapping_uri2name_postal_district():
    with open("wales_uri2name_postal_district.pickle", "rb") as infile:
        mapping_uri2name_postal_district = pickle.load(infile)
    return mapping_uri2name_postal_district




def get_mapping_uri2name_postal_sector():
    with open("wales_uri2name_postal_sector.pickle", "rb") as infile:
        mapping_uri2name_postal_sector = pickle.load(infile)
    return mapping_uri2name_postal_sector

def get_mapping_uri2name_postal_unit():
    with open("wales_uri2name_postal_unit.pickle", "rb") as infile:
        mapping_uri2name_postal_unit = pickle.load(infile)
    return mapping_uri2name_postal_unit

def get_mapping_uri2name_postal_unit_CF():
    with open("wales_uri2name_postal_unit_CF.pickle", "rb") as infile:
        mapping_uri2name_postal_unit_CF = pickle.load(infile)
    return mapping_uri2name_postal_unit_CF



def get_mapping_uri2name_postal_unit_LD():
    with open("wales_uri2name_postal_unit_LD.pickle", "rb") as infile:
        mapping_uri2name_postal_unit_LD = pickle.load(infile)
    return mapping_uri2name_postal_unit_LD



def get_mapping_uri2name_postal_unit_LL():
    with open("wales_uri2name_postal_unit_LL.pickle", "rb") as infile:
        mapping_uri2name_postal_unit_LL = pickle.load(infile)
    return mapping_uri2name_postal_unit_LL


def get_mapping_uri2name_postal_unit_NP():
    with open("wales_uri2name_postal_unit_NP.pickle", "rb") as infile:
        mapping_uri2name_postal_unit_NP = pickle.load(infile)
    return mapping_uri2name_postal_unit_NP



def get_mapping_uri2name_postal_unit_SA():
    with open("wales_uri2name_postal_unit_SA.pickle", "rb") as infile:
        mapping_uri2name_postal_unit_SA = pickle.load(infile)
    return mapping_uri2name_postal_unit_SA



def get_mapping_uri2name_postal_unit_SY():
    with open("wales_uri2name_postal_unit_SY.pickle", "rb") as infile:
        mapping_uri2name_postal_unit_SY = pickle.load(infile)
    return mapping_uri2name_postal_unit_SY



def get_wales_districts_information():
    with open("local_wales_district.pickle", "rb") as infile:
        all_districts = pickle.load(infile)
    return all_districts

def get_wales_wards_information():
    with open("local_wales_wards.pickle", "rb") as infile:
        all_wards = pickle.load(infile)
    return all_wards


def get_wales_parishes_information():
    with open("local_wales_parishes.pickle", "rb") as infile:
        all_parishes = pickle.load(infile)
    return all_parishes



def get_wales_postal_area_information():
    with open("local_wales_postalarea.pickle", "rb") as infile:
        all_area = pickle.load(infile)
    return all_area


def get_wales_postal_district_information():
    with open("local_wales_postal_district.pickle", "rb") as infile:
        all_postal_district = pickle.load(infile)
    return all_postal_district

def get_wales_postal_sector_information():
    with open("local_wales_postal_sector.pickle", "rb") as infile:
        all_postal_sector= pickle.load(infile)
    return all_postal_sector

def get_wales_postal_unit_information():
    with open("local_wales_postal_unit.pickle", "rb") as infile:
        all_postal_unit = pickle.load(infile)
    return all_postal_unit







def get_wales_postal_unit_information_CF():
    with open("local_wales_postal_unit_in_cf.pickle", "rb") as infile:
        all_postal_unit_CF = pickle.load(infile)
    return all_postal_unit_CF

#
#
#
#
def get_wales_postal_unit_information_LD():
    with open("local_wales_postal_unit_in_LD.pickle", "rb") as infile:
        all_postal_unit_LD = pickle.load(infile)
    return all_postal_unit_LD




def get_wales_postal_unit_information_LL():
    with open("local_wales_postal_unit_in_LL.pickle", "rb") as infile:
        all_postal_unit_LL = pickle.load(infile)
    return all_postal_unit_LL




def get_wales_postal_unit_information_NP():
    with open("local_wales_postal_unit_in_NP.pickle", "rb") as infile:
        all_postal_unit_NP = pickle.load(infile)
    return all_postal_unit_NP




def get_wales_postal_unit_information_SA():
    with open("local_wales_postal_unit_in_SA.pickle", "rb") as infile:
        all_postal_unit_SA = pickle.load(infile)
    return all_postal_unit_SA




def get_wales_postal_unit_information_SY():
    with open("local_wales_postal_unit_in_SY.pickle", "rb") as infile:
        all_postal_unit_SY = pickle.load(infile)
    return all_postal_unit_SY


#
# def get_wales_place_information():
#      with open("try_place_ward.pickle", "rb") as infile:
#         all_place = pickle.load(infile)
#      return all_place

# def get_mapping_uri2name_place():
#     with open("wales_uri2name_place_v2.pickle", "rb") as infile:
#         mapping_uri2name_place = pickle.load(infile)
#     return mapping_uri2name_place

def get_wales_place_information():
    with open("place_output_with_ward_updated.pickle", "rb") as infile:
        all_place = pickle.load(infile)
    return all_place



def populate_wales_districts(onto):
    mapping_uri2name_districts = get_mapping_uri2name_districts()
    all_districts = get_wales_districts_information()

    uri2instances = dict()

    District_Administrative_Unit = get_entity(onto, "District_Administrative_Unit")
    Administrative_hierarchy_of_Wales_1 = get_entity(onto, "Administrative_hierarchy_of_Wales_1")
    Administrative_hierarchy_of_Wales_2 = get_entity(onto, "Administrative_hierarchy_of_Wales_2")
    part_of = get_entity(onto, "part_of")
    level_in_hierarchy = get_entity(onto, "level_in_hierarchy")
    OS_id = get_entity(onto, "OS_id")


    # Define the latitude and longitude properties
    lat = get_entity(onto, "lat")
    long = get_entity(onto, "long")




    with onto:
        for uri in all_districts.keys():
            instance_name = mapping_uri2name_districts[uri]

            # Create an instance of District_Administrative_Unit
            instance = District_Administrative_Unit(instance_name)

            # Set properties for the instance
            instance.part_of = [Administrative_hierarchy_of_Wales_1, Administrative_hierarchy_of_Wales_2]
            instance.level_in_hierarchy = 0
            instance.OS_id = uri  # Assuming OS_id is a data property

            # Link the instance to the Ordnance Survey URI using owl:sameAs
            # URIRef is used to ensure that the URI is interpreted correctly.


            # Store the instance in the uri2instances dictionary if needed later
            uri2instances[uri] = instance


           # instance = District_Administrative_Unit(instance_name, part_of = [Administrative_hierarchy_of_Wales_1, Administrative_hierarchy_of_Wales_2], level_in_hierarchy = 0, OS_id = uri, sameAs = uri)
           # uri2instances[uri] = instance

            #instance_name = mapping_uri2name_districts[uri]  # Or however you get the instance name
            #district_instance = onto.District_Administrative_Unit(instance_name)




        for uri, district in all_districts.items():
            current = uri2instances[uri]

            # Retrieve latitude and longitude from your data
            latitude_value = district.latitude
            longitude_value = district.longitude

            # Print latitude and longitude values for debugging
            # print(f"Latitude for {uri}: {latitude_value}")
            # print(f"Longitude for {uri}: {longitude_value}")

            # Set the latitude and longitude properties to the district instance
            if latitude_value is not None:
                current.lat = latitude_value  # Assign directly, no append
            if longitude_value is not None:
                current.long = longitude_value  # Assign directly, no append
            for bearing, values in district.direction.items():
                # note that: values is a dictionanry: {'uri': uri, 'distance': distance}
                neighbour_uri = values['uri']
                neighbour = uri2instances[neighbour_uri]
                if bearing == "N":
                    current.nearest_N.append(neighbour)
                if bearing == "S":
                    current.nearest_S.append(neighbour)
                if bearing == "E":
                    current.nearest_E.append(neighbour)
                if bearing == "W":
                    current.nearest_W.append(neighbour)






# ward

def populate_wales_wards(onto):
    mapping_uri2name_wards = get_mapping_uri2name_wards()
    mapping_uri2name_districts = get_mapping_uri2name_districts()
    all_wards = get_wales_wards_information()

    uri2instances = dict()

    Ward_Administrative_Unit = get_entity(onto, "Ward_Administrative_Unit")
    Administrative_hierarchy_of_Wales_1 = get_entity(onto, "Administrative_hierarchy_of_Wales_1")

    part_of = get_entity(onto, "part_of")
    level_in_hierarchy = get_entity(onto, "level_in_hierarchy")
    ehInside = get_entity(onto, "ehInside")
    OS_id = get_entity(onto, "OS_id")

    # Define the latitude and longitude properties
    lat = get_entity(onto, "lat")
    long = get_entity(onto, "long")

    with onto:
        for uri in all_wards.keys():
            instance_name = mapping_uri2name_wards[uri] + "_Ward"
            instance = Ward_Administrative_Unit(instance_name)
            instance.part_of = [Administrative_hierarchy_of_Wales_1]
            instance.level_in_hierarchy = 1
            instance.OS_id = uri
            uri2instances[uri] = instance

        for uri, ward in all_wards.items():
            current = uri2instances[uri]

            parent_uri = ward.within
            parent_instance_name = mapping_uri2name_districts[parent_uri]
            parent_instance = get_entity(onto, parent_instance_name)

            current.ehInside.append(parent_instance)

            # Retrieve latitude and longitude from your data
            latitude_value = ward.latitude
            longitude_value = ward.longitude

            # Print latitude and longitude values for debugging
            # print(f"Latitude for {uri}: {latitude_value}")
            # print(f"Longitude for {uri}: {longitude_value}")

            # Set the latitude and longitude properties to the district instance
            if latitude_value is not None:
                current.lat = latitude_value  # Assign directly, no append
            if longitude_value is not None:
                current.long = longitude_value  # Assign directly, no append
            for bearing, values in ward.direction.items():
                # note that: values is a dictionanry: {'uri': uri, 'distance': distance}
                neighbour_uri = values['uri']
                neighbour = uri2instances[neighbour_uri]
                if bearing == "N":
                    current.nearest_N.append(neighbour)
                if bearing == "S":
                    current.nearest_S.append(neighbour)
                if bearing == "E":
                    current.nearest_E.append(neighbour)
                if bearing == "W":
                    current.nearest_W.append(neighbour)

            for bearing, values in ward.direction.items():
                # note that: values is a dictionanry: {'uri': uri, 'distance': distance}
                neighbour_uri = values['uri']
                neighbour = uri2instances[neighbour_uri]
                if bearing == "N":
                    current.nearest_N.append(neighbour)
                if bearing == "S":
                    current.nearest_S.append(neighbour)
                if bearing == "E":
                    current.nearest_E.append(neighbour)
                if bearing == "W":
                    current.nearest_W.append(neighbour)








def populate_wales_parishes(onto):
    mapping_uri2name_parishes = get_mapping_uri2name_parishes()
    mapping_uri2name_districts = get_mapping_uri2name_districts()
    all_parishes = get_wales_parishes_information()

    uri2instances = dict()

    Parish_Administrative_Unit = get_entity(onto, "Parish_Administrative_Unit")
    Administrative_hierarchy_of_Wales_2 = get_entity(onto, "Administrative_hierarchy_of_Wales_2")

    part_of = get_entity(onto, "part_of")
    level_in_hierarchy = get_entity(onto, "level_in_hierarchy")
    ehInside = get_entity(onto, "ehInside")
    # Define the latitude and longitude properties
    lat = get_entity(onto, "lat")
    long = get_entity(onto, "long")
    OS_id = get_entity(onto, "OS_id")


    with onto:
        for uri in all_parishes.keys():
            instance_name = mapping_uri2name_parishes[uri] + "_Parish"
            instance = Parish_Administrative_Unit(instance_name,  part_of=[Administrative_hierarchy_of_Wales_2], level_in_hierarchy = 1, OS_id = uri)
            uri2instances[uri] = instance

        for uri, parish in all_parishes.items():
            current = uri2instances[uri]

            parent_uri = parish.within
            parent_instance_name = mapping_uri2name_districts[parent_uri]
            parent_instance = get_entity(onto, parent_instance_name)

            current.ehInside.append(parent_instance)

            # Retrieve latitude and longitude from your data
            latitude_value = parish.latitude
            longitude_value = parish.longtitude

            # Print latitude and longitude values for debugging
            # print(f"Latitude for {uri}: {latitude_value}")
            # print(f"Longitude for {uri}: {longitude_value}")

            # Set the latitude and longitude properties to the district instance
            if latitude_value is not None:
                current.lat = latitude_value  # Assign directly, no append
            if longitude_value is not None:
                current.long = longitude_value  # Assign directly, no appen

            for bearing, values in parish.direction.items():
                # note that: values is a dictionanry: {'uri': uri, 'distance': distance}
                neighbour_uri = values['uri']
                neighbour = uri2instances[neighbour_uri]
                if bearing == "N":
                    current.nearest_N.append(neighbour)
                if bearing == "S":
                    current.nearest_S.append(neighbour)
                if bearing == "E":
                    current.nearest_E.append(neighbour)
                if bearing == "W":
                    current.nearest_W.append(neighbour)



#place1


def populate_wales_places_xx(onto):


    #mapping_uri2name_districts = get_mapping_uri2name_districts()
    mapping_uri2name_postal_unit = get_mapping_uri2name_postal_unit()
    mapping_uri2name_place = get_mapping_uri2name_place()
    mapping_uri2name_wards = get_mapping_uri2name_wards()
    all_place = get_wales_place_information()







    uri2instances = dict()

    Named_Entity = get_entity(onto, "Named_Entity")
    Administrative_hierarchy_of_Wales_2 = get_entity(onto, "Administrative_hierarchy_of_Wales_2")
    Administrative_hierarchy_of_Wales_1 = get_entity(onto, "Administrative_hierarchy_of_Wales_1")
    part_of = get_entity(onto, "part_of")
    ehInside = get_entity(onto, "ehInside")

    #level_in_hierarchy = get_entity(onto, "level_in_hierarchy")



    with onto:
        for uri in all_place.keys():

            instance_name = mapping_uri2name_place[uri]
            instance = Named_Entity(instance_name,  part_of=[Administrative_hierarchy_of_Wales_1, Administrative_hierarchy_of_Wales_2])
            uri2instances[uri] = instance


        for uri, place in all_place.items():

            current = uri2instances[uri]
            parent_uri = place.within
            #parent_uri1 = place.within1

            parent_instance_name = mapping_uri2name_wards.get(parent_uri)
            #parent_instance_name1 = mapping_uri2name_postal_unit.get(parent_uri1)
            #parent_instance_name1 = place.name_postcode_unit
            parent_instance = get_entity(onto, parent_instance_name)
            #parent_instance1 = get_entity(onto, parent_instance_name1)
            if parent_instance is not None:
                current.ehInside.append(parent_instance)
            #if parent_instance1 is not None:
               # current.ehInside.append(parent_instance1)



            #if parent_instance_name is not None:


            #if parent_instance_name1 is not None:






            #print(f"parent_instance1: {parent_instance1}")





           # parent_instance_name = None
            #parent_instance_name1 = None
            #if parent_uri in mapping_uri2name_wards:
               #parent_instance_name = mapping_uri2name_wards[parent_uri]

            #if parent_uri1 in mapping_uri2name_postal_unit:
               #parent_instance_name1 = mapping_uri2name_postal_unit[parent_uri1]
            #parent_instance_name1 = place.name_postcode_unit
            #parent_instance = get_entity(onto, parent_instance_name)
            #parent_instance1 = get_entity(onto, parent_instance_name1)
            #print(f"current: {current}")
            #print(f"parent_instance: {parent_uri}")
            #print(f"parent_instance1: {parent_uri1}")
            #if parent_instance is not None:
               #current.ehInside.append(parent_instance)
            #if parent_instance1 is not None:
               #current.ehInside.append(parent_instance1)

            for bearing, values in place.direction.items():
                neighbour_uri = values['uri']
                if neighbour_uri in uri2instances:
                    neighbour = uri2instances[neighbour_uri]
                    if bearing == "N":
                        current.nearest_N.append(neighbour)
                    if bearing == "S":
                        current.nearest_S.append(neighbour)
                    if bearing == "E":
                        current.nearest_E.append(neighbour)
                    if bearing == "W":
                        current.nearest_W.append(neighbour)
                else:
                    print(f"Warning: neighbour URI {neighbour_uri} not found in uri2instances dictionary")


def populate_wales_places(onto):
    mapping_uri2name_postal_unit = get_mapping_uri2name_postal_unit()
    mapping_uri2name_place = get_mapping_uri2name_place()
    mapping_uri2name_wards = get_mapping_uri2name_wards()
    all_place = get_wales_place_information()

    uri2instances = dict()
    Named_Entity = get_entity(onto, "Named_Entity")
    Administrative_hierarchy_of_Wales_2 = get_entity(onto, "Administrative_hierarchy_of_Wales_2")
    Administrative_hierarchy_of_Wales_1 = get_entity(onto, "Administrative_hierarchy_of_Wales_1")
    Postal_Administrative_hierarchy = get_entity(onto, "Postal_Administrative_hierarchy")
    part_of = get_entity(onto, "part_of")
    ehInside = get_entity(onto, "ehInside")
    # Define the latitude and longitude properties
    lat = get_entity(onto, "lat")
    long = get_entity(onto, "long")
    OS_id = get_entity(onto, "OS_id")


    with onto:
        for uri, place in all_place.items():

            instance_name = mapping_uri2name_place[uri]
            instance = Named_Entity(instance_name,
                                    part_of=[Administrative_hierarchy_of_Wales_1, Administrative_hierarchy_of_Wales_2, Postal_Administrative_hierarchy], OS_id = uri)
            uri2instances[uri] = instance


        for uri, place in all_place.items():
            current = uri2instances[uri]
           # parent_uri1 = place.within1
            parent_uri = place.within_ward
           # print(parent_uri1)

            #if parent_uri is not None:
            parent_instance_name = mapping_uri2name_wards[parent_uri] + "_Ward"
           # parent_instance_name1 = mapping_uri2name_postal_unit[parent_uri1]
            #print(parent_instance_name1)

            parent_instance = get_entity(onto, parent_instance_name)
          #  parent_instance1 = get_entity(onto, parent_instance_name1)

            if parent_instance is not None:
               current.ehInside.append(parent_instance)
            #if parent_instance1 is not None:
              # current.ehInside = parent_instance1






               # Retrieve latitude and longitude from your data
            latitude_value = place.latitude
            longitude_value = place.longitude

               # Print latitude and longitude values for debugging
               # print(f"Latitude for {uri}: {latitude_value}")
               # print(f"Longitude for {uri}: {longitude_value}")

               # Set the latitude and longitude properties to the district instance
            if latitude_value is not None:
                current.lat = latitude_value  # Assign directly, no append
            if longitude_value is not None:
                current.long = longitude_value  # Assign directly, no appen

            for bearing, values in place.direction.items():
                neighbour_uri = values['uri']
                if neighbour_uri in uri2instances:
                    neighbour = uri2instances[neighbour_uri]
                    if bearing == "N":
                        current.nearest_N.append(neighbour)
                    if bearing == "S":
                        current.nearest_S.append(neighbour)
                    if bearing == "E":
                        current.nearest_E.append(neighbour)
                    if bearing == "W":
                        current.nearest_W.append(neighbour)
                else:
                    print(f"Warning: neighbour URI {neighbour_uri} not found in uri2instances dictionary")



def populate_wales_places_x(onto):


    #mapping_uri2name_districts = get_mapping_uri2name_districts()
    mapping_uri2name_postal_unit = get_mapping_uri2name_postal_unit()
    mapping_uri2name_place = get_mapping_uri2name_place()
    mapping_uri2name_wards = get_mapping_uri2name_wards()
    all_place = get_wales_place_information()

    uri2instances = dict()

    Named_Entity = get_entity(onto, "Named_Entity")
    Administrative_hierarchy_of_Wales_2 = get_entity(onto, "Administrative_hierarchy_of_Wales_2")
    Administrative_hierarchy_of_Wales_1 = get_entity(onto, "Administrative_hierarchy_of_Wales_1")
    part_of = get_entity(onto, "part_of")
    ehInside = get_entity(onto, "ehInside")

    #level_in_hierarchy = get_entity(onto, "level_in_hierarchy")

    with onto:

        for uri, place in all_place.items():
            instance_name = mapping_uri2name_place[uri]
            instance = Named_Entity(instance_name,
                                        part_of=[Administrative_hierarchy_of_Wales_1,
                                                 Administrative_hierarchy_of_Wales_2])
            uri2instances[uri] = instance

        for uri, place in all_place.items():
            current = get_entity(onto, uri)
            parent_uri1 = place.name_postcode_unit
            #parent_instance_name1 = mapping_uri2name_postal_unit.get(parent_uri1)
            parent_instance1 = get_entity(onto, parent_uri1)
            if parent_instance1 is not None:
                current.ehInside.append(parent_instance1)


def populate_wales_places_inside_postcode(onto):


    mapping_uri2name_postal_unit = get_mapping_uri2name_postal_unit()
    mapping_uri2name_place = get_mapping_uri2name_place()

    all_place = get_wales_place_information()

    uri2instances = dict()

    Named_Entity = get_entity(onto, "Named_Entity")

    ehInside = get_entity(onto, "ehInside")


    with onto:
        for uri in all_place.keys():
             instance_name = mapping_uri2name_place[uri]
             instance = Named_Entity(instance_name)
             uri2instances[uri] = instance

        for uri, place in all_place.items():

            current = uri2instances[uri]
            parent_uri = place.within1
            parent_instance_name = mapping_uri2name_postal_unit[parent_uri]
            #parent_instance_name = mapping_uri2name_postal_unit[parent_uri]
            parent_instance = onto[parent_instance_name]
            print(parent_instance)
            #if parent_instance_name in onto:
            #parent_instance = get_entity(onto, parent_instance_name)
            if parent_instance is not None:
               current.ehInside.append(parent_instance)

            #print( parent_instance_name)
            #parent_instance = get_entity(onto, parent_instance_name)
            #print(parent_instance)


        #parent_instance_name = mapping_uri2name_postal_unit[parent_uri]


         #   if parent_instance is not None:
               # current.ehInside.append(parent_instance)
     #   else:
           # print(f"Entity name '{parent_instance_name}' does not exist in the ontology.")

        #
#postal area
def populate_wales_postal_area(onto):
    mapping_uri2name_area = get_mapping_uri2name_postal_area()

    all_area = get_wales_postal_area_information()

    uri2instances = dict()

    Postal_Area = get_entity(onto, "Postal_Area")
    Postal_Administrative_hierarchy = get_entity(onto, "Postal_Administrative_hierarchy")
    Administrative_hierarchy_of_Wales_2 = get_entity(onto, "Administrative_hierarchy_of_Wales_2")
    Administrative_hierarchy_of_Wales_1 = get_entity(onto, "Administrative_hierarchy_of_Wales_1")
    OS_id = get_entity(onto, "OS_id")


    part_of = get_entity(onto, "part_of")
    level_in_hierarchy = get_entity(onto, "level_in_hierarchy")


    with onto:
        for uri in all_area.keys():
            instance_name = mapping_uri2name_area[uri]
            instance = Postal_Area(instance_name,  part_of = [Postal_Administrative_hierarchy, Administrative_hierarchy_of_Wales_1, Administrative_hierarchy_of_Wales_2], level_in_hierarchy =0, OS_id = uri)


            uri2instances[uri] = instance

        for uri, area in all_area.items():
            current = uri2instances[uri]

            #parent_uri = ward.within
            #parent_instance_name = mapping_uri2name_districts[parent_uri]
            #parent_instance = get_entity(onto, parent_instance_name)

            #current.ehInside.append(parent_instance)

            #for bearing, values in ward.direction.items():
                # note that: values is a dictionanry: {'uri': uri, 'distance': distance}
               # neighbour_uri = values['uri']
               # neighbour = uri2instances[neighbour_uri]
               # if bearing == "N":
                   # current.nearest_N.append(neighbour)
               # if bearing == "S":
                  #  current.nearest_S.append(neighbour)
               # if bearing == "E":
                #    current.nearest_E.append(neighbour)
               # if bearing == "W":
                 #   current.nearest_W.append(neighbour)





#postal district



def populate_wales_postal_district(onto):
    mapping_uri2name_postal_district = get_mapping_uri2name_postal_district()
    mapping_uri2name_postal_area = get_mapping_uri2name_postal_area()
    all_postal_district = get_wales_postal_district_information()

    uri2instances = dict()

    #Postal_Area = get_entity(onto, "Postal_Area")
    Postal_District = get_entity(onto, "Postal_District")
    Administrative_hierarchy_of_Wales_1 = get_entity(onto, "Administrative_hierarchy_of_Wales_1")
    Administrative_hierarchy_of_Wales_2 = get_entity(onto, "Administrative_hierarchy_of_Wales_2")
    Postal_Administrative_hierarchy = get_entity(onto, "Postal_Administrative_hierarchy")
    ehInside = get_entity(onto, "ehInside")
    part_of = get_entity(onto, "part_of")
    level_in_hierarchy = get_entity(onto, "level_in_hierarchy")
    OS_id = get_entity(onto, "OS_id")


    with onto:
        for uri in all_postal_district.keys():
            instance_name = mapping_uri2name_postal_district[uri]
            instance = Postal_District(instance_name, part_of = [Postal_Administrative_hierarchy, Administrative_hierarchy_of_Wales_1,
                                                                 Administrative_hierarchy_of_Wales_2], level_in_hierarchy = 1, OS_id = uri )


            uri2instances[uri] = instance

        for uri, postal_district in all_postal_district.items():
            current = uri2instances[uri]

            parent_uri = postal_district.within
            parent_instance_name = mapping_uri2name_postal_area[parent_uri]
            parent_instance = get_entity(onto, parent_instance_name)

            current.ehInside.append(parent_instance)

            #for bearing, values in ward.direction.items():
                # note that: values is a dictionanry: {'uri': uri, 'distance': distance}
               # neighbour_uri = values['uri']
               ## neighbour = uri2instances[neighbour_uri]
               # if bearing == "N":
                 ##   current.nearest_N.append(neighbour)
               # if bearing == "S":
                 #   current.nearest_S.append(neighbour)
               # if bearing == "E":
                #    current.nearest_E.append(neighbour)
               # if bearing == "W":
                  #  current.nearest_W.append(neighbour)






#postal dsector



def populate_wales_postal_sector(onto):
    mapping_uri2name_postal_sector = get_mapping_uri2name_postal_sector()
    mapping_uri2name_postal_district = get_mapping_uri2name_postal_district()
    all_postal_sector = get_wales_postal_sector_information()

    uri2instances = dict()

    Postal_Sector = get_entity(onto, "Postal_Sector")
    #Postal_District = get_entity(onto, "Postal_District")
    Administrative_hierarchy_of_Wales_1 = get_entity(onto, "Administrative_hierarchy_of_Wales_1")
    Administrative_hierarchy_of_Wales_2 = get_entity(onto, "Administrative_hierarchy_of_Wales_2")
    Postal_Administrative_hierarchy = get_entity(onto, "Postal_Administrative_hierarchy")
    ehInside = get_entity(onto, "ehInside")
    part_of = get_entity(onto, "part_of")
    OS_id = get_entity(onto, "OS_id")
    level_in_hierarchy = get_entity(onto, "level_in_hierarchy")


    with onto:
        for uri in  all_postal_sector.keys():
            instance_name = mapping_uri2name_postal_sector[uri]
            instance = Postal_Sector(instance_name, part_of = [Postal_Administrative_hierarchy, Administrative_hierarchy_of_Wales_1,
                                                                 Administrative_hierarchy_of_Wales_2], level_in_hierarchy = 2, OS_id = uri )


            uri2instances[uri] = instance

        for uri, postal_sector in all_postal_sector.items():
            current = uri2instances[uri]

            parent_uri = postal_sector.within
            parent_instance_name = mapping_uri2name_postal_district[parent_uri]
            parent_instance = get_entity(onto, parent_instance_name)

            current.ehInside.append(parent_instance)

            #for bearing, values in ward.direction.items():
                # note that: values is a dictionanry: {'uri': uri, 'distance': distance}
               # neighbour_uri = values['uri']
               ## neighbour = uri2instances[neighbour_uri]
               # if bearing == "N":
                 ##   current.nearest_N.append(neighbour)
               # if bearing == "S":
                 #   current.nearest_S.append(neighbour)
               # if bearing == "E":
                #    current.nearest_E.append(neighbour)
               # if bearing == "W":
                  #  current.nearest_W.append(neighbour)




#postal units



def populate_wales_postal_unit(onto):
    mapping_uri2name_postal_unit_CF = get_mapping_uri2name_postal_unit_CF()
    mapping_uri2name_postal_unit_LD = get_mapping_uri2name_postal_unit_LD()
    mapping_uri2name_postal_unit_LL = get_mapping_uri2name_postal_unit_LL()
    mapping_uri2name_postal_unit_NP = get_mapping_uri2name_postal_unit_NP()
    mapping_uri2name_postal_unit_SA = get_mapping_uri2name_postal_unit_SA()
    mapping_uri2name_postal_unit_SY = get_mapping_uri2name_postal_unit_SY()

    mapping_uri2name_wards = get_mapping_uri2name_wards()
    mapping_uri2name_postal_sector = get_mapping_uri2name_postal_sector()


    all_postal_unit_CF = get_wales_postal_unit_information_CF()
    all_postal_unit_LD = get_wales_postal_unit_information_LD()
    all_postal_unit_LL = get_wales_postal_unit_information_LL()
    all_postal_unit_NP = get_wales_postal_unit_information_NP()
    all_postal_unit_SA = get_wales_postal_unit_information_SA()
    all_postal_unit_SY = get_wales_postal_unit_information_SY()


    uri2instances = dict()

    Postal_Unit = get_entity(onto, "Postal_Unit")
    #Postal_District = get_entity(onto, "Postal_District")
    Administrative_hierarchy_of_Wales_1 = get_entity(onto, "Administrative_hierarchy_of_Wales_1")
    Administrative_hierarchy_of_Wales_2 = get_entity(onto, "Administrative_hierarchy_of_Wales_2")
    Postal_Administrative_hierarchy = get_entity(onto, "Postal_Administrative_hierarchy")
    ehInside = get_entity(onto, "ehInside")
    part_of = get_entity(onto, "part_of")
    level_in_hierarchy = get_entity(onto, "level_in_hierarchy")
    # Define the latitude and longitude properties
    lat = get_entity(onto, "lat")
    long = get_entity(onto, "long")
    OS_id = get_entity(onto, "OS_id")


    with onto:
        for uri in  all_postal_unit_CF.keys():
            instance_name = mapping_uri2name_postal_unit_CF[uri]
            instance = Postal_Unit(instance_name, part_of = [Postal_Administrative_hierarchy, Administrative_hierarchy_of_Wales_1,
                                                                 Administrative_hierarchy_of_Wales_2], level_in_hierarchy = 3, OS_id = uri )


            uri2instances[uri] = instance
        #
        for uri, postal_unit in all_postal_unit_CF.items():
            current = uri2instances[uri]

            parent_uri = postal_unit.within
            parent_uri1 = postal_unit.within1
            parent_instance_name = mapping_uri2name_postal_sector[parent_uri]
            parent_instance_name1 = mapping_uri2name_wards[parent_uri1] + "_Ward"
            parent_instance = get_entity(onto, parent_instance_name)
            parent_instance1 = get_entity(onto, parent_instance_name1)
            if parent_instance is not None:
                 current.ehInside.append(parent_instance)
            if parent_instance1 is not None:
                 current.ehInside.append(parent_instance1)
                 # Retrieve latitude and longitude from your data
            latitude_value = postal_unit.latitude
            longitude_value = postal_unit.longitude

                 # Print latitude and longitude values for debugging
                 # print(f"Latitude for {uri}: {latitude_value}")
                 # print(f"Longitude for {uri}: {longitude_value}")

                 # Set the latitude and longitude properties to the district instance
            if latitude_value is not None:
                current.lat = latitude_value  # Assign directly, no append
            if longitude_value is not None:
                current.long = longitude_value  # Assign directly, no appen



            for bearing, values in postal_unit.direction.items():
                # note that: values is a dictionanry: {'uri': uri, 'distance': distance}
               neighbour_uri = values['uri']
               neighbour = uri2instances[neighbour_uri]
               if bearing == "N":
                   current.nearest_N.append(neighbour)
               if bearing == "S":
                   current.nearest_S.append(neighbour)
               if bearing == "E":
                   current.nearest_E.append(neighbour)
               if bearing == "W":
                   current.nearest_W.append(neighbour)


        for uri in all_postal_unit_LD.keys():
            instance_name = mapping_uri2name_postal_unit_LD[uri]
            instance = Postal_Unit(instance_name,
                                       part_of=[Postal_Administrative_hierarchy, Administrative_hierarchy_of_Wales_1,
                                                Administrative_hierarchy_of_Wales_2], level_in_hierarchy = 3, OS_id = uri )

            uri2instances[uri] = instance

        for uri, postal_unit in all_postal_unit_LD.items():
            current = uri2instances[uri]

            parent_uri = postal_unit.within
            parent_uri1 = postal_unit.within1
            parent_instance_name = mapping_uri2name_postal_sector[parent_uri]
            parent_instance_name1 = mapping_uri2name_wards[parent_uri1] + "_Ward"
            parent_instance = get_entity(onto, parent_instance_name)
            parent_instance1 = get_entity(onto, parent_instance_name1)
            if parent_instance is not None:
                current.ehInside.append(parent_instance)
            if parent_instance1 is not None:
                current.ehInside.append(parent_instance1)

                # Retrieve latitude and longitude from your data
            latitude_value = postal_unit.latitude
            longitude_value = postal_unit.longitude

                # Print latitude and longitude values for debugging
                # print(f"Latitude for {uri}: {latitude_value}")
                # print(f"Longitude for {uri}: {longitude_value}")

                # Set the latitude and longitude properties to the district instance
            if latitude_value is not None:
                current.lat = latitude_value  # Assign directly, no append
            if longitude_value is not None:
                current.long = longitude_value  # Assign directly, no appen
            for bearing, values in postal_unit.direction.items():
                # note that: values is a dictionanry: {'uri': uri, 'distance': distance}
                neighbour_uri = values['uri']
                neighbour = uri2instances[neighbour_uri]
                if bearing == "N":
                    current.nearest_N.append(neighbour)
                if bearing == "S":
                    current.nearest_S.append(neighbour)
                if bearing == "E":
                    current.nearest_E.append(neighbour)
                if bearing == "W":
                    current.nearest_W.append(neighbour)


        for uri in all_postal_unit_LL.keys():
            instance_name = mapping_uri2name_postal_unit_LL[uri]
            instance = Postal_Unit(instance_name,
                                   part_of=[Postal_Administrative_hierarchy, Administrative_hierarchy_of_Wales_1,
                                            Administrative_hierarchy_of_Wales_2], level_in_hierarchy = 3, OS_id = uri )

            uri2instances[uri] = instance

        for uri, postal_unit in all_postal_unit_LL.items():
            current = uri2instances[uri]

            parent_uri = postal_unit.within
            parent_uri1 = postal_unit.within1
            parent_instance_name = mapping_uri2name_postal_sector[parent_uri]
            parent_instance_name1 = mapping_uri2name_wards[parent_uri1] + "_Ward"

            parent_instance = get_entity(onto, parent_instance_name)
            parent_instance1 = get_entity(onto, parent_instance_name1)
            if parent_instance is not None:
                 current.ehInside.append(parent_instance)
            if parent_instance1 is not None:
                 current.ehInside.append(parent_instance1)

                 # Retrieve latitude and longitude from your data
            latitude_value = postal_unit.latitude
            longitude_value = postal_unit.longitude

                 # Print latitude and longitude values for debugging
                 # print(f"Latitude for {uri}: {latitude_value}")
                 # print(f"Longitude for {uri}: {longitude_value}")

                 # Set the latitude and longitude properties to the district instance
            if latitude_value is not None:
                current.lat = latitude_value  # Assign directly, no append
            if longitude_value is not None:
                current.long = longitude_value  # Assign directly, no appen
            for bearing, values in postal_unit.direction.items():
                # note that: values is a dictionanry: {'uri': uri, 'distance': distance}
                neighbour_uri = values['uri']
                neighbour = uri2instances[neighbour_uri]
                if bearing == "N":
                    current.nearest_N.append(neighbour)
                if bearing == "S":
                    current.nearest_S.append(neighbour)
                if bearing == "E":
                    current.nearest_E.append(neighbour)
                if bearing == "W":
                    current.nearest_W.append(neighbour)



        for uri in all_postal_unit_NP.keys():
            instance_name = mapping_uri2name_postal_unit_NP[uri]
            instance = Postal_Unit(instance_name,
                                   part_of=[Postal_Administrative_hierarchy, Administrative_hierarchy_of_Wales_1,
                                            Administrative_hierarchy_of_Wales_2], level_in_hierarchy = 3, OS_id = uri)

            uri2instances[uri] = instance

        for uri, postal_unit in all_postal_unit_NP.items():
            current = uri2instances[uri]

            parent_uri = postal_unit.within
            parent_uri1 = postal_unit.within1
            parent_instance_name = mapping_uri2name_postal_sector[parent_uri]
            parent_instance_name1 = mapping_uri2name_wards[parent_uri1] + "_Ward"
            parent_instance = get_entity(onto, parent_instance_name)
            parent_instance1 = get_entity(onto, parent_instance_name1)
            if parent_instance is not None:
                current.ehInside.append(parent_instance)
            if parent_instance1 is not None:
                current.ehInside.append(parent_instance1)

                # Retrieve latitude and longitude from your data
                # Retrieve latitude and longitude from your data
            latitude_value = postal_unit.latitude
            longitude_value = postal_unit.longitude

            # Print latitude and longitude values for debugging
            # print(f"Latitude for {uri}: {latitude_value}")
            # print(f"Longitude for {uri}: {longitude_value}")

            # Set the latitude and longitude properties to the district instance
            if latitude_value is not None:
                current.lat = latitude_value  # Assign directly, no append
            if longitude_value is not None:
                current.long = longitude_value  # Assign directly, no appen
            for bearing, values in postal_unit.direction.items():
                # note that: values is a dictionanry: {'uri': uri, 'distance': distance}
                neighbour_uri = values['uri']
                neighbour = uri2instances[neighbour_uri]
                if bearing == "N":
                    current.nearest_N.append(neighbour)
                if bearing == "S":
                    current.nearest_S.append(neighbour)
                if bearing == "E":
                    current.nearest_E.append(neighbour)
                if bearing == "W":
                    current.nearest_W.append(neighbour)





        for uri in  all_postal_unit_SA.keys():
            instance_name = mapping_uri2name_postal_unit_SA[uri]
            instance = Postal_Unit(instance_name, part_of = [Postal_Administrative_hierarchy, Administrative_hierarchy_of_Wales_1,
                                                                 Administrative_hierarchy_of_Wales_2], level_in_hierarchy = 3, OS_id = uri )


            uri2instances[uri] = instance

        for uri, postal_unit in all_postal_unit_SA.items():
            current = uri2instances[uri]

            parent_uri = postal_unit.within
            parent_uri1 = postal_unit.within1
            parent_instance_name = mapping_uri2name_postal_sector[parent_uri]
            parent_instance_name1 = mapping_uri2name_wards[parent_uri1] + "_Ward"
            parent_instance = get_entity(onto, parent_instance_name)
            parent_instance1 = get_entity(onto, parent_instance_name1)
            if parent_instance is not None:
                current.ehInside.append(parent_instance)
            if parent_instance1 is not None:
                current.ehInside.append(parent_instance1)
                # Retrieve latitude and longitude from your data
                # Retrieve latitude and longitude from your data
            latitude_value = postal_unit.latitude
            longitude_value = postal_unit.longitude

            # Print latitude and longitude values for debugging
            # print(f"Latitude for {uri}: {latitude_value}")
            # print(f"Longitude for {uri}: {longitude_value}")

            # Set the latitude and longitude properties to the district instance
            if latitude_value is not None:
                current.lat = latitude_value  # Assign directly, no append
            if longitude_value is not None:
                current.long = longitude_value  # Assign directly, no appen

            for bearing, values in postal_unit.direction.items():
                # note that: values is a dictionanry: {'uri': uri, 'distance': distance}
                neighbour_uri = values['uri']
                neighbour = uri2instances[neighbour_uri]
                if bearing == "N":
                    current.nearest_N.append(neighbour)
                if bearing == "S":
                    current.nearest_S.append(neighbour)
                if bearing == "E":
                    current.nearest_E.append(neighbour)
                if bearing == "W":
                    current.nearest_W.append(neighbour)



        for uri in  all_postal_unit_SY.keys():
            instance_name = mapping_uri2name_postal_unit_SY[uri]
            instance = Postal_Unit(instance_name, part_of = [Postal_Administrative_hierarchy, Administrative_hierarchy_of_Wales_1,
                                                                 Administrative_hierarchy_of_Wales_2], level_in_hierarchy = 3, OS_id = uri  )


            uri2instances[uri] = instance

        for uri, postal_unit in all_postal_unit_SY.items():
            current = uri2instances[uri]

            parent_uri = postal_unit.within
            parent_uri1 = postal_unit.within1
            parent_instance_name = mapping_uri2name_postal_sector[parent_uri]
            parent_instance_name1 = mapping_uri2name_wards[parent_uri1] + "_Ward"
            parent_instance = get_entity(onto, parent_instance_name)
            parent_instance1 = get_entity(onto, parent_instance_name1)
            if parent_instance is not None:
                current.ehInside.append(parent_instance)
            if parent_instance1 is not None:
                current.ehInside.append(parent_instance1)

                # Retrieve latitude and longitude from your data
            latitude_value = postal_unit.latitude
            longitude_value = postal_unit.longitude

                # Print latitude and longitude values for debugging
                # print(f"Latitude for {uri}: {latitude_value}")
                # print(f"Longitude for {uri}: {longitude_value}")

                # Set the latitude and longitude properties to the district instance
            if latitude_value is not None:
                current.lat = latitude_value  # Assign directly, no append
            if longitude_value is not None:
                current.long = longitude_value  # Assign directly, no appen

            for bearing, values in postal_unit.direction.items():
                # note that: values is a dictionanry: {'uri': uri, 'distance': distance}
                neighbour_uri = values['uri']
                neighbour = uri2instances[neighbour_uri]
                if bearing == "N":
                    current.nearest_N.append(neighbour)
                if bearing == "S":
                    current.nearest_S.append(neighbour)
                if bearing == "E":
                    current.nearest_E.append(neighbour)
                if bearing == "W":
                    current.nearest_W.append(neighbour)








if __name__ == "__main__":
    onto = load_ontology()
    populate_wales_districts(onto)
    populate_wales_wards(onto)
    populate_wales_parishes(onto)
    populate_wales_postal_area(onto)
    populate_wales_postal_district(onto)
    populate_wales_postal_sector(onto)
    populate_wales_postal_unit(onto)
    populate_wales_places(onto)
    populate_wales_places_inside_postcode(onto)
    #populate_wales_places_x(onto)
    #populate_wales_places_2(onto)
    #populate_wales_places_inside_ward(onto)

    #save
    #onto.save('ontology_UK_Wales_with_Coordinates.owl')
    onto.save('ontology_UK_Wales_Dec2023.owl')





from typing import Pattern
from rdflib.term import URIRef
from rdflib import Graph
import rdflib
import pathlib
import pprint
import timeit
import re
import pickle
from geo_unit import GeoUnit


# https://rdflib.readthedocs.io/en/stable/intro_to_parsing.html



#method is used to compile a regular expression pattern provided as a string into a regex pattern object
ontology_iri: Pattern[str] = re.compile("<http://[a-zA-Z0-9,._/ '\-}]+>")

sameas = "<http://www.w3.org/2002/07/owl#sameAs>"
prefLabel = "<http://www.w3.org/2004/02/skos/core#prefLabel>"
altLabel = "<http://www.w3.org/2004/02/skos/core#altLabel>"
easting = "<http://data.ordnancesurvey.co.uk/ontology/spatialrelations/easting>"
northing = "<http://data.ordnancesurvey.co.uk/ontology/spatialrelations/northing>"
ineuropean = "<http://data.ordnancesurvey.co.uk/ontology/admingeo/inEuropeanRegion>"
extent = "<http://data.ordnancesurvey.co.uk/ontology/geometry/extent>"


def fix_uri_with_space(filepath: str):
    lines = []
    with open(filepath, encoding="utf-8") as fin:
        for row in fin.readlines():
            # split by >.<
            items = row.strip().split(">.<")
            #print(items)
            subrows = []
            if len(items) > 1:
                subrows.append(items[0] + ">.")
                for item in items[1:]:
                    subrows.append("<" + item)
            else:
                subrows.append(items[0])

            for subrow in subrows:
                # remove sameas, prefered, altLabel, easting....by skip the iteration
                if sameas in subrow or prefLabel in subrow or altLabel in subrow or easting in subrow or northing in subrow or ineuropean in subrow:
                    continue
                # findall() method iterates over a string to find a subset of characters that match a specified pattern
                uris = re.findall(ontology_iri, subrow)
                if uris:
                    last_uri = uris[-1]
                     #re.sub will replace the bad characters using regliar expression (regex),
                    updated_uri = re.sub('[, }]+', '', last_uri)
                    updated_row = subrow.replace(last_uri, updated_uri)
                    # print(row)
                    lines.append(updated_row)
                else:
                    lines.append(subrow)
    return lines



# parse the files into the graph.
def read_file_with_fixed_uri(g, filepath: str):
    lines = fix_uri_with_space(filepath)
    text = "\n".join(lines)
    g.parse(data=text, format="nt")
    return g


def load_rdf_folder(g, folderpath, name_filter: None):
    for ntfile in pathlib.Path(folderpath).glob('*.nt'):

        if name_filter:
            if not name_filter(str(ntfile)):
                continue
        print("processing ...................{}".format(ntfile))
        g = read_file_with_fixed_uri(g, ntfile)
    return g

# **************************************************************
def store_BoundaryLine_dataset():
    g = Graph()
    #help in customing.
    g = load_rdf_folder(g, "ntriples/BoundaryLine", lambda name: name.endswith(".nt"))
    print("storing Boundryline done" )
    g.serialize(destination="boundaryline.nt", encoding='utf-8', format="ntriples")


# reading the graph after save it.
def load_BoundaryLine_dataset():
    g = Graph()
    g.parse("boundaryline.nt")
    print("loading Boundryline done")
    print(len(g))


def store_OpenNames_dataset():
    g = Graph()
    g = load_rdf_folder(g, "ntriples/OpenNames", lambda name: name.endswith("_nesting.nt"))
    print("storing OpenNames done")
    g.serialize(destination="opennames.nt", encoding='utf-8', format="ntriples")


def load_OpenNames_dataset():
    g = Graph()

    g.parse("opennames.nt")
    print("loading (reading) OpenNames done")
    print(len(g))




def local_query_districts_in_wales():
    g = Graph()
    starttime = timeit.default_timer()
    #g = load_OpenNames_dataset()
    g = load_rdf_folder(g, "ntriples/OpenNames_wales", lambda name: name.endswith("_nesting.nt"))

    print("The loading time is :", timeit.default_timer() - starttime)
    print(len(g))
    all_districts = dict()

    query = """
        SELECT DISTINCT ?district
        WHERE {
        ?x <http://data.ordnancesurvey.co.uk/ontology/admingeo/inCounty> ?district ;
        <http://data.ordnancesurvey.co.uk/ontology/admingeo/inCountry>
         <http://data.ordnancesurvey.co.uk/id/country/wales>.
        }"""
    print(query)
    # run sparql query with local database
    query_result = g.query(query)

    # extract result and save in pickle file
    for row in query_result:
        uri = str(row["district"])
        #The second argument is the default for when it can't find the key.
        geounit = all_districts.get(uri, None)
        if not geounit:
            geounit = GeoUnit(uri)
            geounit.within = "http://data.ordnancesurvey.co.uk/id/country/wales"
            all_districts[uri] = geounit

    with open("local_wales_district.pickle", "wb") as outfile:
        pickle.dump(all_districts, outfile, pickle.HIGHEST_PROTOCOL)







#Named Entity




def local_query_places_in_wales():
    with open("local_wales_district.pickle", "rb") as infile:
        all_districts = pickle.load(infile)
    starttime = timeit.default_timer()
    g = Graph()

    g = load_rdf_folder(g, "ntriples/OpenNames_wales", lambda name: name.endswith(".nt"))

    print("The loading time is :", timeit.default_timer() - starttime)
    print(len(g))


    all_places = dict()

    for uri, geodistrict in all_districts.items():
        print(f"processing ....... {geodistrict.name}")

        sparql_clauses = []
        sparql_clauses.append("SELECT DISTINCT ?namedentity ")
        sparql_clauses.append("WHERE { ")
        sparql_clauses.append(f" ?namedentity  <http://data.ordnancesurvey.co.uk/ontology/admingeo/inCounty> <{uri}>  .")
        sparql_clauses.append("} ")

        query = "\n".join(sparql_clauses)
        query_result = g.query(query)
        print(query)
        for row in query_result:
            placeuri = str(row["namedentity"])
            geounit = all_places.get(placeuri, None)
            if not geounit:
                geounit = GeoUnit(placeuri)
                geounit.within = uri
                all_places[placeuri] = geounit

    with open("local_wales_places_v2.pickle", "wb") as outfile:
        pickle.dump(all_places, outfile, pickle.HIGHEST_PROTOCOL)




# Ward

def local_query_wards_in_wales():
    with open("local_wales_district.pickle", "rb") as infile:
        all_districts = pickle.load(infile)
    g = Graph()
    starttime = timeit.default_timer()
    g = load_rdf_folder(g, "ntriples/BoundaryLine", lambda name: name.endswith(".nt"))
    print("The loading time is :", timeit.default_timer() - starttime)
    print(len(g))
    all_wards = dict()
    for uri, geodistrict in all_districts.items():
        print(f"processing ....... {geodistrict.name}")
        sparql_clauses = []
        sparql_clauses.append("SELECT DISTINCT ?ward ")
        sparql_clauses.append("WHERE { ")
        sparql_clauses.append(f" <{uri}>  <http://data.ordnancesurvey.co.uk/ontology/admingeo/ward> ?ward  .")
        sparql_clauses.append("} ")

        query = "\n".join(sparql_clauses)
        #query =  """
           # SELECT DISTINCT ?ward
          #     WHERE {
          #     f" <{uri}>  <http://data.ordnancesurvey.co.uk/ontology/admingeo/ward> ?ward ."
                 
         #   }"""
        print(query)
        query_result = g.query(query)
        for row in query_result:
            warduri = str(row["ward"])
            geounit = all_wards.get(warduri, None)
            if not geounit:
                geounit = GeoUnit(warduri)
                geounit.within = uri
                all_wards[warduri] = geounit

    with open("local_wales_wards.pickle", "wb") as outfile:
        pickle.dump(all_wards, outfile, pickle.HIGHEST_PROTOCOL)







#Parish



def local_query_parishes_in_wales():
    with open("local_wales_district.pickle", "rb") as infile:
        all_districts = pickle.load(infile)
    g = Graph()
    g = load_rdf_folder(g, "ntriples/BoundaryLine", lambda name: name.endswith(".nt"))
    print("The loading time is :", timeit.default_timer() - starttime)
    print(len(g))

# create dictionary
    all_parishes = dict()

    for uri, geodistrict in all_districts.items():
        print(f"processing ....... {geodistrict.name}")
        sparql_clauses = []
        sparql_clauses.append("SELECT DISTINCT ?parish ")
        sparql_clauses.append("WHERE { ")
        sparql_clauses.append(f" <{uri}>   <http://data.ordnancesurvey.co.uk/ontology/admingeo/parish>   ?parish .")

        sparql_clauses.append("} ")
        query = "\n".join(sparql_clauses)
        query_result = g.query(query)
        # query =  """
        # SELECT DISTINCT ?ward
        #     WHERE {
        #     f" <{uri}>  <http://data.ordnancesurvey.co.uk/ontology/admingeo/ward> ?ward ."

        #   }"""
        #print(query)
        for row in query_result:
            parishuri = str(row["parish"])
            geounit = all_parishes.get(parishuri, None)
            if not geounit:
                geounit = GeoUnit(parishuri)
                geounit.within = uri
                all_parishes[parishuri] = geounit

    with open("local_wales_parishes.pickle", "wb") as outfile:
        pickle.dump(all_parishes, outfile, pickle.HIGHEST_PROTOCOL)







# PostCode Area




def local_query_postal_area_in_wales():
    g = Graph()

    #g = load_OpenNames_dataset()
    g = load_rdf_folder(g, "ntriples/CodePoint_Wales", lambda name: name.endswith(".nt"))
    print("The loading time is :", timeit.default_timer() - starttime)
    print(len(g))
    all_area = dict()

    sparql_clauses = []
    sparql_clauses.append("SELECT DISTINCT ?postalarea ")
    sparql_clauses.append("WHERE { ")
    sparql_clauses.append("?x <http://data.ordnancesurvey.co.uk/ontology/spatialrelations/within> ?postalarea.")
    sparql_clauses.append("?postalarea <http://www.w3.org/1999/02/22-rdf-syntax-ns#type>  <http://data.ordnancesurvey.co.uk/ontology/postcode/PostcodeArea>.")
    sparql_clauses.append( "?x <http://data.ordnancesurvey.co.uk/ontology/postcode/country> <http://data.ordnancesurvey.co.uk/id/country/wales>.")
    sparql_clauses.append("} ")

    query = "\n".join(sparql_clauses)
    query_result = g.query(query)
    print(query)


    # run sparql query with local database
    query_result = g.query(query)

    # extract result and save in pickle file
    for row in query_result:
        uri = str(row["postalarea"])
        #The second argument is the default for when it can't find the key.
        geounit = all_area.get(uri, None)
        if not geounit:
            geounit = GeoUnit(uri)
            geounit.within = "http://data.ordnancesurvey.co.uk/id/country/wales"
            all_area[uri] = geounit

    with open("local_wales_postalarea.pickle", "wb") as outfile:
        pickle.dump(all_area, outfile, pickle.HIGHEST_PROTOCOL)








# Poatal District

def local_query_postal_district_in_wales():
    with open("local_wales_postalarea.pickle", "rb") as infile:
        all_area = pickle.load(infile)

    g = Graph()

    g = load_rdf_folder(g, "ntriples/CodePoint_Wales", lambda name: name.endswith(".nt"))
    print("The loading time is :", timeit.default_timer() - starttime)
    print(len(g))
    # create dictionary
    all_postaldistrict = dict()
    for uri, geoarea in all_area.items():
        print(f"processing ....... {geoarea.name}")
        sparql_clauses = []
        sparql_clauses.append("SELECT DISTINCT ?postaldistrict ")
        sparql_clauses.append("WHERE { ")
        sparql_clauses.append(f" ?postaldistrict <http://data.ordnancesurvey.co.uk/ontology/spatialrelations/within> <{uri}> .")
        sparql_clauses.append("?postaldistrict <http://www.w3.org/1999/02/22-rdf-syntax-ns#type>  <http://data.ordnancesurvey.co.uk/ontology/postcode/PostcodeDistrict>.")
   # sparql_clauses.append( "?x <http://data.ordnancesurvey.co.uk/ontology/postcode/country> <http://data.ordnancesurvey.co.uk/id/country/wales>.")
        sparql_clauses.append("} ")

        query = "\n".join(sparql_clauses)
        query_result = g.query(query)
        print(query)
    # run sparql query with local database
        query_result = g.query(query)

    # extract result and save in pickle file
        for row in query_result:
            postaldistrict_uri = str(row["postaldistrict"])
        #The second argument is the default for when it can't find the key.
            geounit = all_postaldistrict.get(postaldistrict_uri, None)
            if not geounit:
                geounit = GeoUnit(postaldistrict_uri)
                geounit.within = uri
                all_postaldistrict[postaldistrict_uri] = geounit

    with open("local_wales_postal_district.pickle", "wb") as outfile:
        pickle.dump(all_postaldistrict, outfile, pickle.HIGHEST_PROTOCOL)


# Postal sector



def local_query_postal_sector_in_wales():
    with open("local_wales_postal_district.pickle", "rb") as infile:
        all_postaldistrict = pickle.load(infile)

    g = Graph()

    g = load_rdf_folder(g, "ntriples/CodePoint_Wales", lambda name: name.endswith(".nt"))
    print("The loading time is :", timeit.default_timer() - starttime)
    print(len(g))
    # create dictionary
    all_postal_sector = dict()
    for uri, geodistrict in all_postaldistrict.items():
        print(f"processing ....... {geodistrict.name}")
        sparql_clauses = []
        sparql_clauses.append("SELECT DISTINCT ?postalsector ")
        sparql_clauses.append("WHERE { ")
        sparql_clauses.append(f" ?postalsector <http://data.ordnancesurvey.co.uk/ontology/spatialrelations/within> <{uri}> .")
        sparql_clauses.append("?postalsector <http://www.w3.org/1999/02/22-rdf-syntax-ns#type>  <http://data.ordnancesurvey.co.uk/ontology/postcode/PostcodeSector>.")
   # sparql_clauses.append( "?x <http://data.ordnancesurvey.co.uk/ontology/postcode/country> <http://data.ordnancesurvey.co.uk/id/country/wales>.")
        sparql_clauses.append("} ")

        query = "\n".join(sparql_clauses)
        query_result = g.query(query)
        print(query)

    # run sparql query with local database
        query_result = g.query(query)
    # extract result and save in pickle file
        for row in query_result:
             postalsector_uri = str(row["postalsector"])
        #The second argument is the default for when it can't find the key.
             geounit = all_postal_sector.get(postalsector_uri, None)
             if not geounit:
                 geounit = GeoUnit(postalsector_uri)
                 geounit.within = uri
                 all_postal_sector[postalsector_uri] = geounit

    with open("local_wales_postal_sector.pickle", "wb") as outfile:
        pickle.dump(all_postal_sector, outfile, pickle.HIGHEST_PROTOCOL)








# Postal Unit
def local_query_postal_unit_in_wales():
    with open("local_wales_postal_sector.pickle", "rb") as infile:
        all_sector = pickle.load(infile)



    g = Graph()

    g = load_rdf_folder(g, "ntriples/CodePoint_Wales", lambda name: name.endswith(".nt"))
    print("The loading time is :", timeit.default_timer() - starttime)
    print(len(g))


    # create dictionary
    all_postal_unit = dict()

    for uri, geosector in all_sector.items():
        print(f"processing ....... {geosector.name}")
        sparql_clauses = []
        sparql_clauses.append("SELECT DISTINCT ?postalunit ")
        sparql_clauses.append("WHERE { ")
        sparql_clauses.append(f" ?postalunit <http://data.ordnancesurvey.co.uk/ontology/spatialrelations/within> <{uri}> .")
        sparql_clauses.append("?postalunit <http://www.w3.org/1999/02/22-rdf-syntax-ns#type>  <http://data.ordnancesurvey.co.uk/ontology/postcode/PostcodeUnit>.")
   # sparql_clauses.append( "?x <http://data.ordnancesurvey.co.uk/ontology/postcode/country> <http://data.ordnancesurvey.co.uk/id/country/wales>.")
        sparql_clauses.append("} ")

        query = "\n".join(sparql_clauses)
        query_result = g.query(query)
        print(query)


    # run sparql query with local database
        query_result = g.query(query)

        # extract result and save in pickle file
        for row in query_result:
            postalunit_uri = str(row["postalunit"])
            # The second argument is the default for when it can't find the key.
            geounit = all_postal_unit.get(postalunit_uri, None)
            if not geounit:
                geounit = GeoUnit(postalunit_uri)
                geounit.within = uri
                all_postal_unit[postalunit_uri] = geounit

    with open("local_wales_postal_unit_s.pickle", "wb") as outfile:
         pickle.dump(all_postal_unit, outfile, pickle.HIGHEST_PROTOCOL)













# Postal Unit
def local_query_postal_unit_updated_inside_in_wales():
    with open("local_wales_wards.pickle", "rb") as infile:
        all_words = pickle.load(infile)

    g = Graph()

    g = load_rdf_folder(g, "ntriples/CodePoint_Wales", lambda name: name.endswith(".nt"))
    print("The loading time is :", timeit.default_timer() - starttime)
    print(len(g))

    # create dictionary
    all_postal_unit_ward = dict()

    for uri, geoward in all_words.items():
        print(f"processing ....... {geoward.name}")
        sparql_clauses = []
        sparql_clauses.append("SELECT DISTINCT ?postalunit ")
        sparql_clauses.append("WHERE { ")
        sparql_clauses.append(f" ?postalunit <http://data.ordnancesurvey.co.uk/ontology/postcode/ward> <{uri}> .")
        sparql_clauses.append("?postalunit <http://www.w3.org/1999/02/22-rdf-syntax-ns#type>  <http://data.ordnancesurvey.co.uk/ontology/postcode/PostcodeUnit>.")
   # sparql_clauses.append( "?x <http://data.ordnancesurvey.co.uk/ontology/postcode/country> <http://data.ordnancesurvey.co.uk/id/country/wales>.")
        sparql_clauses.append("} ")

        query = "\n".join(sparql_clauses)
        query_result = g.query(query)
        print(query)


    # run sparql query with local database
        query_result = g.query(query)





    # extract result and save in pickle file
        for row in query_result:
             postalunit_uri = str(row["postalunit"])
        #The second argument is the default for when it can't find the key.
             geounit = all_postal_unit_ward.get(postalunit_uri, None)
             if not geounit:
                 geounit = GeoUnit(postalunit_uri)
                 geounit.within = uri
                 all_postal_unit_ward[postalunit_uri] = geounit

    with open("local_wales_postal_unit_w.pickle", "wb") as outfile:
        pickle.dump(all_postal_unit_ward, outfile, pickle.HIGHEST_PROTOCOL)










# Postal Unit inside sector
def local_query_postal_unit_updated_inside_CF():
    with open("local_wales_postal_sector.pickle", "rb") as infile:
         all_sector = pickle.load(infile)

    #with open("local_wales_wards.pickle", "rb") as file:
         #all_ward = pickle.load(file)

    g = Graph()
    #g1 = Graph()

    g = load_rdf_folder(g, "ntriples/CodePoint_Wales", lambda name: name.endswith(".nt"))
    #g1 = load_rdf_folder(g, "ntriples/CodePoint_Wales", lambda name: name.endswith(".nt"))

    # create dictionary
    all_postal_unit = dict()

    for uris, geosector in all_sector.items():
        print(f"processing ....... {geosector.name}")

        #for uriw, geoward in all_ward.items():
            #print(f"processing ....... {geoward.name}")
        sparql_clauses1 = []
        sparql_clauses1.append("SELECT DISTINCT ?postalunit ")
        sparql_clauses1.append("WHERE { ")
        sparql_clauses1.append( " ?postalunit <http://data.ordnancesurvey.co.uk/ontology/spatialrelations/within> <http://data.ordnancesurvey.co.uk/id/postcodearea/SY>.")
        sparql_clauses1.append(f" ?postalunit <http://data.ordnancesurvey.co.uk/ontology/spatialrelations/within> <{uris}> .")
        #sparql_clauses1.append(f" ?postalunit <http://data.ordnancesurvey.co.uk/ontology/spatialrelations/within> <{uriw}> .")
        sparql_clauses1.append("?postalunit <http://www.w3.org/1999/02/22-rdf-syntax-ns#type>  <http://data.ordnancesurvey.co.uk/ontology/postcode/PostcodeUnit> .")
       #sparql_clauses1.append( "?x <http://data.ordnancesurvey.co.uk/ontology/postcode/country> <http://data.ordnancesurvey.co.uk/id/country/wales>.")
        sparql_clauses1.append("} ")


        query = "\n".join(sparql_clauses1)
            #print(query)
        query_result1 = g.query(query)

        # run sparql query with local database
        #query_result1 = g.query(query)

        for row in query_result1:
            postalunit_uri = str(row["postalunit"])
            # The second argument is the default for when it can't find the key.
            geounit = all_postal_unit.get(postalunit_uri, None)
            if not geounit:
                geounit = GeoUnit(postalunit_uri)
                # geounit.within = "http://data.ordnancesurvey.co.uk/id/postcodedistrict/LD>"
                geounit.within = uris
                #geounit.within1 = uriw
                all_postal_unit[postalunit_uri] = geounit
       #print(query1)
    # query = """
    #        SELECT DISTINCT ?postalunit
    #        WHERE {
    #            ?postalunit <http://data.ordnancesurvey.co.uk/ontology/spatialrelations/within> <http://data.ordnancesurvey.co.uk/id/postcodearea/LD>.
    #            ?postalunit <http://data.ordnancesurvey.co.uk/ontology/spatialrelations/within> <{uri}>
    #            ?postalunit <http://data.ordnancesurvey.co.uk/ontology/spatialrelations/within> <{uri}>
    #            ?postalunit <http://www.w3.org/1999/02/22-rdf-syntax-ns#type>  <http://data.ordnancesurvey.co.uk/ontology/postcode/PostcodeUnit> .
    #        }"""


    #query_result = g.query(query)



    # run sparql query with local database


    # for uriw, geoward in all_ward.items():
    #     sparql_clauses = []
    #     sparql_clauses.append("SELECT DISTINCT ?postalunit ")
    #     sparql_clauses.append("WHERE { ")
    #     #sparql_clauses.append( f" ?postalunit <http://data.ordnancesurvey.co.uk/ontology/spatialrelations/within> <{uris}> .")
    #     #sparql_clauses.append(" ?postalunit <http://data.ordnancesurvey.co.uk/ontology/spatialrelations/within> <http://data.ordnancesurvey.co.uk/id/postcodearea/LD>.")
    #     sparql_clauses.append(f" ?postalunit <http://data.ordnancesurvey.co.uk/ontology/spatialrelations/within> <{uriw}> .")
    #     sparql_clauses.append("?postalunit <http://www.w3.org/1999/02/22-rdf-syntax-ns#type>  <http://data.ordnancesurvey.co.uk/ontology/postcode/PostcodeUnit>.")
    #     #sparql_clauses.append("?x <http://data.ordnancesurvey.co.uk/ontology/postcode/country> <http://data.ordnancesurvey.co.uk/id/country/wales>.")
    #     sparql_clauses.append("} ")
    #     # query = """
    #     #        SELECT DISTINCT ?postalunit
    #     #        WHERE {
    #     #            ?postalunit <http://data.ordnancesurvey.co.uk/ontology/spatialrelations/within> <http://data.ordnancesurvey.co.uk/id/postcodearea/LD>.
    #     #            ?postalunit <http://data.ordnancesurvey.co.uk/ontology/spatialrelations/within> <{uri}>
    #     #            ?postalunit <http://data.ordnancesurvey.co.uk/ontology/spatialrelations/within> <{uri}>
    #     #            ?postalunit <http://www.w3.org/1999/02/22-rdf-syntax-ns#type>  <http://data.ordnancesurvey.co.uk/ontology/postcode/PostcodeUnit> .
    #     #        }"""
    #
    #
    #     #print(query)
    #     query = "\n".join(sparql_clauses)
    #     query_result = g1.query(query)
    #     print(query)
    #     # run sparql query with local database
    #     query_result = g1.query(query)
    #
    #
    #
    #
    #
    #     for row in query_result:
    #     #postalunit_uri = str(row["postalunit"])
    #     #The second argument is the default for when it can't find the key.
    #     #geounit = all_postal_unit.get(postalunit_uri, None)
    #     #if not geounit:
    #        #geounit = GeoUnit(postalunit_uri)
    #        #geounit.within = "http://data.ordnancesurvey.co.uk/id/postcodedistrict/LD>"
    #        #geounit.within = uris
    #         geounit.within1 = uriw
    #         all_postal_unit[postalunit_uri] = geounit


    with open("local_wales_postal_unit_in_SY_sector.pickle", "wb") as outfile:
        pickle.dump(all_postal_unit, outfile, pickle.HIGHEST_PROTOCOL)



# Postal Unit inside ward
def local_query_postal_unit_updated_inside_ward_sector():
    with open("local_wales_postal_sector.pickle", "rb") as infile:
         all_sector = pickle.load(infile)

    with open("local_wales_wards.pickle", "rb") as file:
         all_ward = pickle.load(file)

    g = Graph()
    #g1 = Graph()

    g = load_rdf_folder(g, "ntriples/CodePoint_Wales", lambda name: name.endswith(".nt"))
    print("The loading time is :", timeit.default_timer() - starttime)
    print(len(g))
    #g1 = load_rdf_folder(g, "ntriples/CodePoint_Wales", lambda name: name.endswith(".nt"))

    # create dictionary
    all_postal_unit = dict()

    for uris, geosector in all_sector.items():
        print(f"processing ....... {geosector.name}")

        for uri, geoward in all_ward.items():
            #print(f"processing ....... {geoward.name}")
            sparql_clauses1 = []
            sparql_clauses1.append("SELECT DISTINCT ?postalunit ")
            sparql_clauses1.append("WHERE { ")
            sparql_clauses1.append( " ?postalunit <http://data.ordnancesurvey.co.uk/ontology/spatialrelations/within> <http://data.ordnancesurvey.co.uk/id/postcodearea/CF>.")
            sparql_clauses1.append(f" ?postalunit <http://data.ordnancesurvey.co.uk/ontology/spatialrelations/within> <{uris}> .")

            sparql_clauses1.append(f" ?postalunit <http://data.ordnancesurvey.co.uk/ontology/postcode/ward> <{uri}> .")
            sparql_clauses1.append("?postalunit <http://www.w3.org/1999/02/22-rdf-syntax-ns#type>  <http://data.ordnancesurvey.co.uk/ontology/postcode/PostcodeUnit> .")
       #sparql_clauses1.append( "?x <http://data.ordnancesurvey.co.uk/ontology/postcode/country> <http://data.ordnancesurvey.co.uk/id/country/wales>.")
            sparql_clauses1.append("} ")


            query = "\n".join(sparql_clauses1)
            #print(query)
            query_result1 = g.query(query)

        # run sparql query with local database
        #query_result1 = g.query(query)

            for row in query_result1:
                 postalunit_uri = str(row["postalunit"])
            # The second argument is the default for when it can't find the key.
                 geounit = all_postal_unit.get(postalunit_uri, None)
                 if not geounit:
                     geounit = GeoUnit(postalunit_uri)
              # geounit.within = "http://data.ordnancesurvey.co.uk/id/postcodedistrict/LD>"
                     geounit.within = uris
                     geounit.within1 = uri
                     all_postal_unit[postalunit_uri] = geounit
       #print(query1)
    # query = """
    #        SELECT DISTINCT ?postalunit
    #        WHERE {
    #            ?postalunit <http://data.ordnancesurvey.co.uk/ontology/spatialrelations/within> <http://data.ordnancesurvey.co.uk/id/postcodearea/LD>.
    #            ?postalunit <http://data.ordnancesurvey.co.uk/ontology/spatialrelations/within> <{uri}>
    #            ?postalunit <http://data.ordnancesurvey.co.uk/ontology/spatialrelations/within> <{uri}>
    #            ?postalunit <http://www.w3.org/1999/02/22-rdf-syntax-ns#type>  <http://data.ordnancesurvey.co.uk/ontology/postcode/PostcodeUnit> .
    #        }"""


    #query_result = g.query(query)



    # run sparql query with local database


    # for uriw, geoward in all_ward.items():
    #     sparql_clauses = []
    #     sparql_clauses.append("SELECT DISTINCT ?postalunit ")
    #     sparql_clauses.append("WHERE { ")
    #     #sparql_clauses.append( f" ?postalunit <http://data.ordnancesurvey.co.uk/ontology/spatialrelations/within> <{uris}> .")
    #     #sparql_clauses.append(" ?postalunit <http://data.ordnancesurvey.co.uk/ontology/spatialrelations/within> <http://data.ordnancesurvey.co.uk/id/postcodearea/LD>.")
    #     sparql_clauses.append(f" ?postalunit <http://data.ordnancesurvey.co.uk/ontology/spatialrelations/within> <{uriw}> .")
    #     sparql_clauses.append("?postalunit <http://www.w3.org/1999/02/22-rdf-syntax-ns#type>  <http://data.ordnancesurvey.co.uk/ontology/postcode/PostcodeUnit>.")
    #     #sparql_clauses.append("?x <http://data.ordnancesurvey.co.uk/ontology/postcode/country> <http://data.ordnancesurvey.co.uk/id/country/wales>.")
    #     sparql_clauses.append("} ")
    #     # query = """
    #     #        SELECT DISTINCT ?postalunit
    #     #        WHERE {
    #     #            ?postalunit <http://data.ordnancesurvey.co.uk/ontology/spatialrelations/within> <http://data.ordnancesurvey.co.uk/id/postcodearea/LD>.
    #     #            ?postalunit <http://data.ordnancesurvey.co.uk/ontology/spatialrelations/within> <{uri}>
    #     #            ?postalunit <http://data.ordnancesurvey.co.uk/ontology/spatialrelations/within> <{uri}>
    #     #            ?postalunit <http://www.w3.org/1999/02/22-rdf-syntax-ns#type>  <http://data.ordnancesurvey.co.uk/ontology/postcode/PostcodeUnit> .
    #     #        }"""
    #
    #
    #     #print(query)
    #     query = "\n".join(sparql_clauses)
    #     query_result = g1.query(query)
    #     print(query)
    #     # run sparql query with local database
    #     query_result = g1.query(query)
    #
    #
    #
    #
    #
    #     for row in query_result:
    #     #postalunit_uri = str(row["postalunit"])
    #     #The second argument is the default for when it can't find the key.
    #     #geounit = all_postal_unit.get(postalunit_uri, None)
    #     #if not geounit:
    #        #geounit = GeoUnit(postalunit_uri)
    #        #geounit.within = "http://data.ordnancesurvey.co.uk/id/postcodedistrict/LD>"
    #        #geounit.within = uris
    #         geounit.within1 = uriw
    #         all_postal_unit[postalunit_uri] = geounit


    with open("local_wales_postal_unit_in_CF.pickle", "wb") as outfile:
        pickle.dump(all_postal_unit, outfile, pickle.HIGHEST_PROTOCOL)



# to add lat and long and nighboures
def local_update_geounit(geounit_pickle_path):
    with open(geounit_pickle_path, "rb") as infile:
        all_units = pickle.load(infile)
    starttime = timeit.default_timer()
    g = Graph()
    g = load_rdf_folder(g, "ntriples/BoundaryLine", lambda name: name.endswith(".nt"))
    print("The loading time is :", timeit.default_timer() - starttime)


    print(len(g))
    for uri, geounit in all_units.items():
        sparql_clauses = []
        sparql_clauses.append("SELECT ?name ?lat ?long ")
        sparql_clauses.append("WHERE { ")
        sparql_clauses.append(f"   <{uri}> <http://www.w3.org/2000/01/rdf-schema#label> ?name ;")
        sparql_clauses.append("             <http://www.w3.org/2003/01/geo/wgs84_pos#lat> ?lat ;")
        sparql_clauses.append("             <http://www.w3.org/2003/01/geo/wgs84_pos#long> ?long .")
        #sparql_clauses.append("    OPTIONAL  {")
        #sparql_clauses.append(f"       <{uri}> <http://data.ordnancesurvey.co.uk/ontology/spatialrelations/touches> ?touchuri .")
        #sparql_clauses.append("} ")
        sparql_clauses.append("} ")
        query = "\n".join(sparql_clauses)
        query_result = g.query(query)

       # query = """
         #   SELECT ?name ?lat ?long (str(?touchuri) as ?touch)
         #   WHERE {
         #     f"   <{uri}> <http://www.w3.org/2000/01/rdf-schema#label> ?name ;"
          #    <http://www.w3.org/2003/01/geo/wgs84_pos#lat> ?lat ;
          #    <http://www.w3.org/2003/01/geo/wgs84_pos#long> ?long .
          #  }"""
        #print(query)
        for row in query_result:
            geounit.name = row["name"]
            geounit.latitude = float(row["lat"])
            geounit.longitude = float(row["long"])
    with open(geounit_pickle_path, "wb") as outfile:
        pickle.dump(all_units, outfile, pickle.HIGHEST_PROTOCOL)



#############


# to add name to postal Area and Postal District and Postal sector
def local_update_geounit_postal(geounit_pickle_path):
    with open(geounit_pickle_path, "rb") as infile:
        all_units = pickle.load(infile)

    g = Graph()

    g = load_rdf_folder(g, "ntriples/CodePoint_Wales", lambda name: name.endswith(".nt"))
    print("The loading time is :", timeit.default_timer() - starttime)
    print(len(g))



    for uri, geounit in all_units.items():
        sparql_clauses = []
        sparql_clauses.append("SELECT ?name ?lat ?long ")
        sparql_clauses.append("WHERE { ")
        sparql_clauses.append(f"   <{uri}> <http://www.w3.org/2000/01/rdf-schema#label> ?name ;")
        sparql_clauses.append("             <http://www.w3.org/2003/01/geo/wgs84_pos#lat> ?lat ;")
        sparql_clauses.append("             <http://www.w3.org/2003/01/geo/wgs84_pos#long> ?long .")
        # sparql_clauses.append("    OPTIONAL  {")
        # sparql_clauses.append(f"       <{uri}> <http://data.ordnancesurvey.co.uk/ontology/spatialrelations/touches> ?touchuri .")
        # sparql_clauses.append("} ")
        sparql_clauses.append("} ")

        query = "\n".join(sparql_clauses)
        query_result = g.query(query)

        # query = """
        #   SELECT ?name ?lat ?long (str(?touchuri) as ?touch)
        #   WHERE {
        #     f"   <{uri}> <http://www.w3.org/2000/01/rdf-schema#label> ?name ;"
        #    <http://www.w3.org/2003/01/geo/wgs84_pos#lat> ?lat ;
        #    <http://www.w3.org/2003/01/geo/wgs84_pos#long> ?long .

        #  }"""

        # print(query)

        for row in query_result:
            geounit.name = row["name"]
            geounit.latitude = float(row["lat"])
            geounit.longitude = float(row["long"])
            # touch = str(row["touch"])
            # print(touch)
            # if touch not in geounit.neighbours:
            #  geounit.neighbours.append(touch)

    with open(geounit_pickle_path, "wb") as outfile:
        pickle.dump(all_units, outfile, pickle.HIGHEST_PROTOCOL)



# for the name place
# to add lat and long and nighboures
def local_update_geounit_place(geounit_pickle_path):
    with open(geounit_pickle_path, "rb") as infile:
        all_units = pickle.load(infile)

    g = Graph()

    g = load_rdf_folder(g, "ntriples/OpenNames_wales", lambda name: name.endswith(".nt"))

    print(len(g))

    for uri, geounit in all_units.items():
        sparql_clauses = []
        sparql_clauses.append("SELECT ?name ?lat ?long ")
        sparql_clauses.append("WHERE { ")
        sparql_clauses.append(f"   <{uri}> <http://xmlns.com/foaf/0.1/name> ?name ;")
        sparql_clauses.append("             <http://www.w3.org/2003/01/geo/wgs84_pos#lat> ?lat ;")
        sparql_clauses.append("             <http://www.w3.org/2003/01/geo/wgs84_pos#long> ?long .")
        # sparql_clauses.append("    OPTIONAL  {")
        # sparql_clauses.append(f"       <{uri}> <http://data.ordnancesurvey.co.uk/ontology/spatialrelations/touches> ?touchuri .")
        # sparql_clauses.append("} ")
        sparql_clauses.append("} ")

        query = "\n".join(sparql_clauses)
        query_result = g.query(query)

        # query = """
        #   SELECT ?name ?lat ?long (str(?touchuri) as ?touch)
        #   WHERE {
        #     f"   <{uri}> <http://www.w3.org/2000/01/rdf-schema#label> ?name ;"
        #    <http://www.w3.org/2003/01/geo/wgs84_pos#lat> ?lat ;
        #    <http://www.w3.org/2003/01/geo/wgs84_pos#long> ?long .

        #  }"""

        # print(query)

        for row in query_result:
            geounit.name = row["name"]
            geounit.latitude = float(row["lat"])
            geounit.longitude = float(row["long"])
            # touch = str(row["touch"])
            # print(touch)
            # if touch not in geounit.neighbours:
            #  geounit.neighbours.append(touch)

    with open(geounit_pickle_path, "wb") as outfile:
        pickle.dump(all_units, outfile, pickle.HIGHEST_PROTOCOL)





def make_uri_name(label: str):
     label = re.sub(r'[^a-zA-Z0-9]', "_", label)
     return label

#create dic that save just uri and name
def create_mapping_geoid_to_instance_name_district():
    mappings = dict()
    with open("local_wales_district.pickle", "rb") as infile:
        all_districts = pickle.load(infile)

    for district_uri, district in all_districts.items():
        generated_name = make_uri_name(district.name)
        mappings[district_uri] = generated_name


    with open("wales_uri2name_district.pickle", "wb") as outfile:
        pickle.dump(mappings, outfile, pickle.HIGHEST_PROTOCOL)




#create dic that save just uri and name
def create_mapping_geoid_to_instance_name_ward():
    mappings = dict()
    with open("local_wales_wards.pickle", "rb") as infile:
        all_wards = pickle.load(infile)

    for ward_uri, ward in all_wards.items():
        generated_name = make_uri_name(ward.name)
        mappings[ward_uri] = generated_name


    with open("wales_uri2name_ward.pickle", "wb") as outfile:
        pickle.dump(mappings, outfile, pickle.HIGHEST_PROTOCOL)



    # create dic that save just uri and name
def create_mapping_geoid_to_instance_name_parish():
    mappings = dict()
    with open("local_wales_parishes.pickle", "rb") as infile:
        all_parishes = pickle.load(infile)

    for parish_uri, parish in all_parishes.items():
        generated_name = make_uri_name(parish.name)
        mappings[parish_uri] = generated_name

    with open("wales_uri2name_parish.pickle", "wb") as outfile:
        pickle.dump(mappings, outfile, pickle.HIGHEST_PROTOCOL)





#create dic that save just uri and name
def create_mapping_geoid_to_instance_name_place():
    mappings = dict()
    with open("place_name_post_code_ward_ready_modified.pickle", "rb") as infile:
        all_places = pickle.load(infile)

    for place_uri, place in all_places.items():
        generated_name = make_uri_name(place.name)
        mappings[place_uri] = generated_name


    with open("wales_uri2name_place_ready_modified.pickle", "wb") as outfile:
        pickle.dump(mappings, outfile, pickle.HIGHEST_PROTOCOL)





#create dic that save just uri and name
def create_mapping_geoid_to_instance_postal_area():
    mappings = dict()
    with open("local_wales_postalarea.pickle", "rb") as infile:
        all_area = pickle.load(infile)

    for postalarea_uri, area in all_area.items():
        generated_name = make_uri_name(area.name)
        mappings[postalarea_uri] = generated_name


    with open("wales_uri2name_postal_area.pickle", "wb") as outfile:
        pickle.dump(mappings, outfile, pickle.HIGHEST_PROTOCOL)





#create dic that save just uri and name
def create_mapping_geoid_to_instance_postal_district():
    mappings = dict()
    with open("local_wales_postal_district.pickle", "rb") as infile:
        all_postal_district = pickle.load(infile)

    for postal_district_uri, postal_district in all_postal_district.items():
        generated_name = make_uri_name(postal_district.name)
        mappings[postal_district_uri] = generated_name


    with open("wales_uri2name_postal_district.pickle", "wb") as outfile:
        pickle.dump(mappings, outfile, pickle.HIGHEST_PROTOCOL)




#create dic that save just uri and name
def create_mapping_geoid_to_instance_postal_sector():
    mappings = dict()
    with open("local_wales_postal_sector.pickle", "rb") as infile:
        all_postal_sector = pickle.load(infile)

    for postal_sector_uri, postal_sector in all_postal_sector.items():
        generated_name = make_uri_name(postal_sector.name)
        mappings[postal_sector_uri] = generated_name


    with open("wales_uri2name_postal_sector.pickle", "wb") as outfile:
        pickle.dump(mappings, outfile, pickle.HIGHEST_PROTOCOL)

#mapping postal unit



# def create_mapping_geoid_to_instance_postal_unit_Matched():
#     mappings = dict()
#     with open("local_wales_postal_unit.pickle", "rb") as infile:
#         all_postal_unit = pickle.load(infile)
#
#     for postal_unit_uri, postal_unit in all_postal_unit.items():
#         generated_name = make_uri_name(postal_unit.name)
#         mappings[postal_unit_uri] = generated_name
#
#     with open("wales_uri2name_postal_unit.pickle", "wb") as outfile:
#         pickle.dump(mappings, outfile, pickle.HIGHEST_PROTOCOL)



def create_mapping_geoid_to_instance_postal_unit():
    mappings = dict()
    with open("local_wales_postal_unit.pickle", "rb") as infile:
        all_postal_unit = pickle.load(infile)

    for postal_unit_uri, postal_unit in all_postal_unit.items():
        generated_name = make_uri_name(postal_unit.name)
        mappings[postal_unit_uri] = generated_name


    with open("wales_uri2name_postal_unit.pickle", "wb") as outfile:
        pickle.dump(mappings, outfile, pickle.HIGHEST_PROTOCOL)




def create_mapping_geoid_to_instance_postal_unit_CF():
    mappings = dict()
    with open("local_wales_postal_unit_in_cf.pickle", "rb") as infile:
        all_postal_unit = pickle.load(infile)

    for postal_unit_uri, postal_unit in all_postal_unit.items():
        generated_name = make_uri_name(postal_unit.name)
        mappings[postal_unit_uri] = generated_name


    with open("wales_uri2name_postal_unit_CF.pickle", "wb") as outfile:
        pickle.dump(mappings, outfile, pickle.HIGHEST_PROTOCOL)







def create_mapping_geoid_to_instance_postal_unit_LD():
    mappings = dict()
    with open("local_wales_postal_unit_in_LD.pickle", "rb") as infile:
        all_postal_unit = pickle.load(infile)

    for postal_unit_uri, postal_unit in all_postal_unit.items():
        generated_name = make_uri_name(postal_unit.name)
        mappings[postal_unit_uri] = generated_name


    with open("wales_uri2name_postal_unit_LD.pickle", "wb") as outfile:
        pickle.dump(mappings, outfile, pickle.HIGHEST_PROTOCOL)




def create_mapping_geoid_to_instance_postal_unit_LL():
    mappings = dict()
    with open("local_wales_postal_unit_in_LL.pickle", "rb") as infile:
        all_postal_unit = pickle.load(infile)

    for postal_unit_uri, postal_unit in all_postal_unit.items():
        generated_name = make_uri_name(postal_unit.name)
        mappings[postal_unit_uri] = generated_name


    with open("wales_uri2name_postal_unit_LL.pickle", "wb") as outfile:
        pickle.dump(mappings, outfile, pickle.HIGHEST_PROTOCOL)


def create_mapping_geoid_to_instance_postal_unit_NP():
    mappings = dict()
    with open("local_wales_postal_unit_in_NP.pickle", "rb") as infile:
        all_postal_unit = pickle.load(infile)

    for postal_unit_uri, postal_unit in all_postal_unit.items():
        generated_name = make_uri_name(postal_unit.name)
        mappings[postal_unit_uri] = generated_name

    with open("wales_uri2name_postal_unit_NP.pickle", "wb") as outfile:
        pickle.dump(mappings, outfile, pickle.HIGHEST_PROTOCOL)


def create_mapping_geoid_to_instance_postal_unit_SA():
    mappings = dict()
    with open("local_wales_postal_unit_in_SA.pickle", "rb") as infile:
        all_postal_unit = pickle.load(infile)

    for postal_unit_uri, postal_unit in all_postal_unit.items():
        generated_name = make_uri_name(postal_unit.name)
        mappings[postal_unit_uri] = generated_name

    with open("wales_uri2name_postal_unit_SA.pickle", "wb") as outfile:
        pickle.dump(mappings, outfile, pickle.HIGHEST_PROTOCOL)


def create_mapping_geoid_to_instance_postal_unit_SY():
    mappings = dict()
    with open("local_wales_postal_unit_in_SY.pickle", "rb") as infile:
        all_postal_unit = pickle.load(infile)

    for postal_unit_uri, postal_unit in all_postal_unit.items():
        generated_name = make_uri_name(postal_unit.name)
        mappings[postal_unit_uri] = generated_name

    with open("wales_uri2name_postal_unit_SY.pickle", "wb") as outfile:
        pickle.dump(mappings, outfile, pickle.HIGHEST_PROTOCOL)




def create_mapping_geoid_to_instance_place():
    mappings = dict()
    with open("place_output_with_ward_updated.pickle", "rb") as infile:
        all_place = pickle.load(infile)

    for place_uri, place in all_place.items():
        generated_name = make_uri_name(place.name)
        mappings[place_uri] = generated_name

    with open("wales_uri2name_place_output_with_ward_updated.pickle", "wb") as outfile:
        pickle.dump(mappings, outfile, pickle.HIGHEST_PROTOCOL)





def create_mapping_geoid_to_instance_place2():
    mappings = dict()
    with open("local_wales_two_places.pickle", "rb") as infile:
        all_place = pickle.load(infile)

    for place_uri, place in all_place.items():
        generated_name = make_uri_name(place.name)
        mappings[place_uri] = generated_name

    with open("wales_uri2name_two_place.pickle", "wb") as outfile:
        pickle.dump(mappings, outfile, pickle.HIGHEST_PROTOCOL)




if __name__ == "__main__":
         #create_mapping_geoid_to_instance_name_district()
        #create_mapping_geoid_to_instance_name_ward()
         #create_mapping_geoid_to_instance_name_parish()
        create_mapping_geoid_to_instance_place()
        # # create_mapping_geoid_to_instance_postal_area()
            #create_mapping_geoid_to_instance_postal_unit()
        #   #create_mapping_geoid_to_instance_postal_district()
        #   #create_mapping_geoid_to_instance_postal_sector()
        #   create_mapping_geoid_to_instance_postal_unit_CF()
        #   create_mapping_geoid_to_instance_postal_unit_LD()
        #   create_mapping_geoid_to_instance_postal_unit_LL()
        #   create_mapping_geoid_to_instance_postal_unit_NP()
        #   create_mapping_geoid_to_instance_postal_unit_SA()
        #   create_mapping_geoid_to_instance_postal_unit_SY()
            #create_mapping_geoid_to_instance_place1()
            #create_mapping_geoid_to_instance_place2()
           # local_query_districts_in_wales()
           #
           # local_update_geounit("local_wales_district.pickle")

          # local_query_places_in_wales()
          #
          # local_update_geounit_place("local_wales_places_v2.pickle")

            #local_query_wards_in_wales()
         #
            #local_update_geounit("local_wales_wards.pickle")

         #local_query_parishes_in_wales()

         #local_update_geounit("local_wales_parishes.pickle")

         #local_query_postal_area_in_wales()
         #local_update_geounit_postal("local_wales_postalarea.pickle")

          #local_query_postal_district_in_wales()
         # local_update_geounit_postal("local_wales_postal_district.pickle")


         #local_query_postal_sector_in_wales()
         #local_update_geounit_postal("local_wales_postal_sector.pickle")

           # local_query_postal_unit_updated_inside_ward_sector()
           # local_update_geounit_postal("local_wales_postal_unit_in_CF.pickle")




          #local_query_postal_unit_in_wales()


          #ocal_query_postal_unit_updated_inside_in_wales()
          #local_query_postal_unit_updated_inside_in_wales()
          #local_update_geounit_postal("local_wales_postal_unit_s.pickle")
          #local_update_geounit_postal("local_wales_postal_unit_w.pickle")





       #store_BoundaryLine_dataset()
      # load_BoundaryLine_dataset()

      #store_OpenNames_dataset()
       #load_OpenNames_dataset()
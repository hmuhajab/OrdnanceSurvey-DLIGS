from pygeodesy.sphericalNvector import LatLon
from pyproj import Transformer
from OSGridConverter import grid2latlong
from shapely.geometry import Point, Polygon
import pickle
import pyproj

#
# # #double check with this conversion
def convert_XY_to_latlong(x1, y1):
#     #source_crs = 'epsg:3031'  # Coordinate system of the file
#     #target_crs = 'epsg:4326'  # Global lat-lon coordinate system
#      proj = pyproj.Transformer.from_crs("EPSG:27700", "EPSG:4326", always_xy=True)
#      lat, lon = proj.transform(x1, y1)
    srcProj = pyproj.Proj(init='epsg:27700', preserve_units=True)
    dstProj = pyproj.Proj(init='epsg:4326', preserve_units=True)

    lat, lon = pyproj.transform(srcProj, dstProj, x1, y1)
    return lat, lon
#
#
# def xy_to_lonlat(x, y):
#     proj_latlon = pyproj.Proj(proj='latlong',datum='WGS84')
#     proj_xy = pyproj.Proj(proj="utm", zone=33, datum='WGS84')
#     lonlat = pyproj.transform(proj_xy, proj_latlon, x, y)
#     return lonlat[0], lonlat[1]
# # #
# def convert_XY_to_latlong(x1, y1):
#
#     l = grid2latlong(x1, y1)
#     lat, lon = (l.latitude, l.longitude)
#     return lat, lon



def get_point(lat, lon):
    return LatLon(lat, lon)


class Polygon:
    def __init__(self):
        self.polygon = []
    
    def add_point(self, lat, lon):
        self.polygon.append(LatLon(lat, lon))

    def is_containing_point(self, lat, lon):
        p = get_point(lat, lon)
        # double check with checking position inside a polygon : it's reliable
        return p.isenclosedBy(self.polygon)


def check_point_inside_polygons(lat, lon, polygons: list):
    for polygon in polygons:
        if polygon.is_containing_point(lat, lon):
            return True
    return False


class GeoChecker:
    def __init__(self):
        # load all wards geo data saved from previous step
        with open("local_wales_wards_geometry.pickle", "rb") as infile:
            self.wards_geomerties = pickle.load(infile)

    # convert geo data of a ward into list of polygons
    def get_ward_geometry(self, warduri):
        ward_geometry_coordinates = self.wards_geomerties.get(warduri)
        ward_polygons = []
        if ward_geometry_coordinates:
            for subarea in ward_geometry_coordinates:
                polygon = Polygon()
                for boundary_point in subarea:
                    x = boundary_point[0]
                    y = boundary_point[1]
                    lat, lon = convert_XY_to_latlong(x, y)

                    #lat, lon = xy_to_lonlat(x,y)
                    polygon.add_point(lat, lon)
                # add sub-area polygon to ward polygon
                ward_polygons.append(polygon)
        return ward_polygons

    # check if a point is inside a ward's polygons
    def check_point_in_ward(self, warduri, lat, lon):
        ward_polygons = self.get_ward_geometry(warduri)
        # p = get_point(lat, lon)
        return check_point_inside_polygons(lat, lon, ward_polygons)

    # checking for multiple points --> saving time for conversion geo data into polygons
    def check_multi_points_in_ward(self, warduri, points: list):
        results = []
        ward_polygons = self.get_ward_geometry(warduri)
        # print(ward_polygons)
        for point in points:
            lat = point[0]
            lon = point[1]
            checking_result = check_point_inside_polygons(lat, lon, ward_polygons)
            results.append(checking_result)
        return results


if __name__ == "__main__":
    # load GeoChecker
    geochecker = GeoChecker()

    # load pickle file of wards   

    # ward
    Fairwood = "http://data.ordnancesurvey.co.uk/id/7000000000025850"

    Castle = "http://data.ordnancesurvey.co.uk/id/7000000000181968"

    Cathays = "http://data.ordnancesurvey.co.uk/id/7000000000019014"


    # name place
    Glyncollen_Primary_School = "http://data.ordnancesurvey.co.uk/id/4000000073307140"
    Glyncollen_Primary_School_lat = 51.682372
    Glyncollen_Primary_School_lon = -3.918563



    # name place
    Ger_Y_Ffrwd = "http://data.ordnancesurvey.co.uk/id/4000000021060953"
    Ger_Y_Ffrwd_lat = 51.650385
    Ger_Y_Ffrwd_lon = -3.888156



    # name place
    Cathays_Park = "http://data.ordnancesurvey.co.uk/id/4000000074557896"
    Cathays_Park_lat = 51.486344
    Cathays_Park_lon = -3.176817









    name_places = {}
    
    name_places[Glyncollen_Primary_School] = (Glyncollen_Primary_School_lat, Glyncollen_Primary_School_lon)
    name_places[Ger_Y_Ffrwd] = (Ger_Y_Ffrwd_lat, Ger_Y_Ffrwd_lon)
#    name_places[Upper_Killay] = (Upper_Killay_lat, Upper_Killay_lon)
    name_places[Cathays_Park] = (Cathays_Park_lat, Cathays_Park_lon)

    name_place_uris = list(name_places.keys())
    # print(name_place_uris)

    name_place_points = list(name_places.values())

    results = geochecker.check_multi_points_in_ward(Cathays, name_place_points)

    for i in range(len(name_place_uris)):
        print(f"Check {name_place_uris[i]} belong to {Cathays} : {results[i]}")

